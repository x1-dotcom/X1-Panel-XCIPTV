<?php
declare(strict_types=1); require_once __DIR__.'/../lib/bootstrap.php';require_admin();require_once __DIR__.'/_layout.php'; $c=config();$app=$c['app']??[];$dev=rows('devices');$logs=rows('logs');$licenses=rows('licenses');$now=time();$cut24=$now-86400; $recentLogs=array_values(array_filter($logs,fn($x)=>strtotime((string)($x['created_at']??'1970-01-01'))>=$cut24)); $errors=array_values(array_filter($recentLogs,fn($x)=>(int)($x['http_status']??0)>=400||in_array(strtoupper((string)($x['success']??'')),['0','FALSE','FAIL','ERROR'],true))); $dur=array_map(fn($x)=>(int)($x['duration_ms']??0),$recentLogs);sort($dur);$p95=$dur?($dur[(int)floor((count($dur)-1)*.95)]??0):0; $online=count(array_filter($dev,function($x)use($now){$seen=strtotime((string)($x['last_seen']??'1970-01-01'));return strtolower((string)($x['online']??''))==='yes'&&$seen!==false&&($now-$seen)<=600;})); $blocked=0;$expired=0;foreach($licenses as $l){$st=license_state($l);if($st['state']==='EXPIRED')$expired++;elseif(!$st['allowed'])$blocked++;} $activeLic=max(0,count($licenses)-$blocked-$expired); $apk=PANEL_ROOT.'/uploads/x1-latest.apk';$apkOk=is_file($apk)&&filesize($apk)>0;$dataOk=is_writable(DATA_DIR)&&is_file(CONFIG_FILE)&&is_file(STORE_FILE);$apiOk=is_file(PANEL_ROOT.'/api/ApiIPTV.php')&&extension_loaded('openssl');$systemOk=$dataOk&&$apiOk; $lastErrors=array_reverse(array_slice($errors,-6));$lastDevices=$dev;usort($lastDevices,fn($a,$b)=>strcmp((string)($b['last_seen']??''),(string)($a['last_seen']??'')));$lastDevices=array_slice($lastDevices,0,6); $alerts=x1_alerts();$unread=unread_notifications();$hh=(array)(store()['health_history']??[]);$lastHealth=$hh?end($hh):null;$openTasks=count(array_filter(ops_tasks(),fn($t)=>(string)($t['status']??'OPEN')!=='DONE')); $errorRate=count($recentLogs)?count($errors)*100/count($recentLogs):0;$reliability=max(0,100-$errorRate); $hours=array_fill(0,24,0);foreach($recentLogs as $r){$ts=strtotime((string)($r['created_at']??''));if($ts===false)continue;$age=(int)floor(($now-$ts)/3600);if($age>=0&&$age<24)$hours[23-$age]++;}$maxHour=max(1,max($hours)); $moduleStates=[ ['API',$apiOk,'ApiIPTV.php'],['Backup',is_file(PANEL_ROOT.'/api/CloudBackup.php'),'CloudBackup.php'],['TMDB',is_file(PANEL_ROOT.'/api/movies.php'),'movies.php'],['Sports',is_file(PANEL_ROOT.'/api/sport.php'),'sport.php'],['Intro',is_file(PANEL_ROOT.'/api/intro.mp4'),'intro.mp4'],['Logo',is_file(PANEL_ROOT.'/api/logo.png'),'logo.png'],['OpenSSL',extension_loaded('openssl'),'crypto'],['Storage',$dataOk,'data'] ]; top('Dashboard'); ?>
<section class="command-hero">
  <div class="command-copy">
    <div class="status-line"><span class="status-orb <?=$systemOk?'is-ok':'is-warn'?>"></span><span><?=$systemOk?'Sistema operacional':'Atenção necessária'?></span></div>
    <h2>Centro de controlo X1</h2>
    <p>Visão consolidada da aplicação, dispositivos, API e operação do painel.</p>
    <div class="hero-meta"><span>API <b><?=$apiOk?'ONLINE':'ISSUE'?></b></span><span>Storage <b><?=$dataOk?'OK':'ISSUE'?></b></span><span>APK <b><?=$apkOk?'PUBLICADA':'NÃO PUBLICADA'?></b></span></div>
  </div>
  <div class="hero-actions"><a class="btn primary" href="diagnostics.php">Executar diagnóstico</a><a class="btn ghost" href="updates.php">Gerir APK</a></div>
</section>

<?php if($alerts):?><section class="priority-alert"><div><span class="priority-kicker">AÇÃO NECESSÁRIA</span><strong><?=count($alerts)?> alerta(s) ativo(s)</strong><small>Existem condições que merecem revisão operacional.</small></div><a href="alerts.php">Abrir Centro de Alertas →</a></section><?php endif?>

<section class="kpi-grid">
  <article class="kpi-card kpi-primary"><div class="kpi-top"><span>Dispositivos online</span><span class="kpi-icon">●</span></div><div class="kpi-value"><?=h((string)$online)?></div><div class="kpi-foot"><strong><?=count($dev)?></strong> registados <span>· contacto ≤ 10 min</span></div></article>
  <article class="kpi-card"><div class="kpi-top"><span>Licenças ativas</span><span class="kpi-icon">◆</span></div><div class="kpi-value"><?=h((string)$activeLic)?></div><div class="kpi-foot"><strong><?=$blocked?></strong> bloqueadas <span>· <?=$expired?> expiradas</span></div></article>
  <article class="kpi-card"><div class="kpi-top"><span>Confiabilidade API</span><span class="kpi-icon">⌁</span></div><div class="kpi-value"><?=number_format($reliability,1)?>%</div><div class="kpi-foot"><strong><?=count($recentLogs)?></strong> pedidos / 24h <span>· p95 <?=$p95?> ms</span></div></article>
  <article class="kpi-card"><div class="kpi-top"><span>Versão APK</span><span class="kpi-icon">⇧</span></div><div class="kpi-value"><?=h((string)($app['version_code']??'—'))?></div><div class="kpi-foot"><strong><?=$apkOk?number_format(filesize($apk)/1024/1024,1).' MB':'Sem APK'?></strong> <span>· auto update <?=h((string)($app['apkautoupdate']??'—'))?></span></div></article>
</section>

<section class="dashboard-main-grid">
  <article class="panel-card traffic-card">
    <div class="panel-heading"><div><span class="section-kicker">TRÁFEGO</span><h3>Atividade API · 24 horas</h3></div><div class="metric-inline"><b><?=count($recentLogs)?></b><span>pedidos</span></div></div>
    <div class="traffic-bars" aria-label="API requests over 24 hours"><?php foreach($hours as $i=>$count):$pct=max(5,(int)round(($count/$maxHour)*100));?><div class="traffic-col" title="<?=$count?> pedidos"><i style="height:<?=$pct?>%"></i><span><?=($i%4===3)?sprintf('%02dh',($i+1+((int)date('G')-24)+24)%24):''?></span></div><?php endforeach?></div>
    <div class="traffic-footer"><div><span class="dot ok-dot"></span><b><?=number_format($reliability,1)?>%</b> sucesso</div><div><span class="dot danger-dot"></span><b><?=count($errors)?></b> falhas</div><div><b><?=$p95?> ms</b> latência p95</div></div>
  </article>

  <article class="panel-card action-center">
    <div class="panel-heading"><div><span class="section-kicker">PRIORIDADES</span><h3>Centro operacional</h3></div></div>
    <a class="action-row" href="notifications.php"><span class="action-icon">●</span><div><strong>Notificações</strong><small>Eventos que ainda não foram revistos</small></div><b><?=$unread?></b></a>
    <a class="action-row" href="ops_tasks.php"><span class="action-icon">✓</span><div><strong>Tarefas abertas</strong><small>Pendências da equipa e operação</small></div><b><?=$openTasks?></b></a>
    <a class="action-row" href="health.php"><span class="action-icon">♥</span><div><strong>Último health check</strong><small><?=h((string)($lastHealth['created_at']??'Sem execução'))?></small></div><b class="<?=$lastHealth&&!empty($lastHealth['ok'])?'text-ok':'text-warn'?>"><?=$lastHealth?(!empty($lastHealth['ok'])?'OK':'FALHA'):'—'?></b></a>
  </article>
</section>

<section class="dashboard-secondary-grid">
  <article class="panel-card">
    <div class="panel-heading"><div><span class="section-kicker">UTILIZADORES</span><h3>Últimos dispositivos</h3></div><a href="devices.php">Ver todos →</a></div>
    <?php if(!$lastDevices):?><div class="empty-state"><span>◇</span><strong>Ainda não há dispositivos</strong><small>Os dispositivos aparecem aqui após o primeiro contacto com a API.</small></div><?php else:?><div class="data-list"><?php foreach($lastDevices as $x):$seen=strtotime((string)($x['last_seen']??'1970-01-01'));$on=strtolower((string)($x['online']??''))==='yes'&&$seen!==false&&($now-$seen)<=600;?><div class="data-row"><div class="device-avatar"><?=h(strtoupper(substr((string)($x['userid']??'?'),0,1)))?></div><div class="data-main"><strong><?=h($x['userid']??'')?></strong><small><?=h($x['app_name']??'Aplicação')?> · <?=h($x['last_seen']??'')?></small></div><span class="state-badge <?=$on?'online':'offline'?>"><?=$on?'ONLINE':'OFFLINE'?></span></div><?php endforeach?></div><?php endif?>
  </article>

  <article class="panel-card">
    <div class="panel-heading"><div><span class="section-kicker">INCIDENTES</span><h3>Falhas API recentes</h3></div><a href="logs.php?kind=api">Abrir logs →</a></div>
    <?php if(!$lastErrors):?><div class="empty-state success"><span>✓</span><strong>Operação limpa</strong><small>Sem falhas registadas nas últimas 24 horas.</small></div><?php else:?><div class="data-list"><?php foreach($lastErrors as $x):?><div class="data-row"><span class="error-pulse"></span><div class="data-main"><strong><?=h($x['tag']??'API')?> · HTTP <?=h($x['http_status']??'')?></strong><small><?=h($x['userid']??'—')?> · <?=h($x['created_at']??'')?></small></div><b><?=h($x['duration_ms']??'')?> ms</b></div><?php endforeach?></div><?php endif?>
  </article>
</section>

<section class="panel-card services-card">
  <div class="panel-heading"><div><span class="section-kicker">INFRAESTRUTURA</span><h3>Estado dos módulos</h3></div><a href="api_test.php">Executar suite HTTP →</a></div>
  <div class="service-grid"><?php foreach($moduleStates as [$n,$ok,$sub]):?><div class="service-item"><span class="service-light <?=$ok?'good':'bad'?>"></span><div><strong><?=h($n)?></strong><small><?=h($sub)?></small></div><span class="service-state <?=$ok?'good':'bad'?>"><?=$ok?'ONLINE':'ISSUE'?></span></div><?php endforeach?></div>
</section>
<?php bottom(); 