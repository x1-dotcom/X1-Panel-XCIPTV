<?php
function x1_nav_link(string $href,string $label,string $icon='•'): void { $active=basename((string)($_SERVER['PHP_SELF']??''))===$href?' active':''; echo '<a class="nav-link'.$active.'" href="'.h($href).'"><span class="nav-icon">'.h($icon).'</span><span>'.h($label).'</span></a>'; } function x1_nav_group(string $label): void { echo '<div class="nav-group">'.h($label).'</div>'; } function top(string $title): void { $me=current_admin();$alerts=count(x1_alerts());$page=basename((string)($_SERVER['PHP_SELF']??'')); ?><!doctype html><html lang="<?=h(ui_lang())?>"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title><?=h($title)?> · X1</title><link rel="stylesheet" href="../assets/admin.css"></head><body>
<aside class="sidebar">
  <div class="brand-block"><div class="brand-mark"><img src="../assets/logo.png" alt="X1"></div><div class="brand-copy"><strong>X1</strong><span>CONTROL SYSTEM</span></div></div>
  <nav class="side-nav">
    <?php x1_nav_group('Visão geral'); ?>
    <?php x1_nav_link('index.php','Dashboard','◇'); ?>
    <?php x1_nav_link('alerts.php','Alertas X1'.($alerts?' ('.$alerts.')':''),'!'); ?>
    <?php x1_nav_link('notifications.php','Notificações'.(unread_notifications()?' ('.unread_notifications().')':''),'●'); ?>

    <?php x1_nav_group('Aplicação'); ?>
    <?php x1_nav_link('app.php','Configurações gerais','⌁'); ?>
    <?php x1_nav_link('customize.php','Personalizar APK','✦'); ?>
    <?php x1_nav_link('home_editor.php','Editor visual da Home','▦'); ?>
    <?php x1_nav_link('features.php','Ativar / Desativar','◫'); ?>
    <?php x1_nav_link('interface.php','Interface / Botões','⊞'); ?>
    <?php x1_nav_link('theme.php','Tema','◐'); ?>
    <?php x1_nav_link('language.php','Idioma','文'); ?>
    <?php x1_nav_link('players.php','Players','▶'); ?>
    <?php x1_nav_link('logo.php','Marca / Logo X1','X'); ?>
    <?php x1_nav_link('intro.php','Intro X1','▷'); ?>

    <?php x1_nav_group('Utilizadores'); ?>
    <?php x1_nav_link('devices.php','Dispositivos','▣'); ?>
    <?php x1_nav_link('licenses.php','Licenças / Acesso','◆'); ?>
    <?php x1_nav_link('profiles.php','Editor visual de Perfis','◈'); ?>
    <?php x1_nav_link('apk_lab.php','Laboratório APK','⌬'); ?>

    <?php x1_nav_group('Conteúdo & serviços'); ?>
    <?php x1_nav_link('vpn.php','VPN','⌁'); ?>
    <?php x1_nav_link('tmdb.php','TMDB','◉'); ?>
    <?php x1_nav_link('sports.php','Sports','⚡'); ?>
    <?php x1_nav_link('announcements.php','Anúncio global','◌'); ?>
    <?php x1_nav_link('messages.php','Mensagens','✉'); ?>
    <?php x1_nav_link('appads.php','AdMob','▤'); ?>
    <?php x1_nav_link('parental.php','PIN Parental','⌾'); ?>

    <?php x1_nav_group('Operações'); ?>
    <?php x1_nav_link('health.php','Health Checks','♥'); ?>
    <?php x1_nav_link('ops_tasks.php','Tarefas Operacionais','✓'); ?>
    <?php x1_nav_link('maintenance.php','Manutenção','⌂'); ?>
    <?php x1_nav_link('updates.php','Atualização remota','⇧'); ?>
    <?php x1_nav_link('backups.php','Cloud Backup APK','☁'); ?>
    <?php x1_nav_link('panel_backup.php','Backup do Painel X1','▱'); ?>
    <?php x1_nav_link('migration.php','Assistente de Migração','⇄'); ?>

    <?php x1_nav_group('Sistema'); ?>
    <?php x1_nav_link('diagnostics.php','Diagnóstico X1','⊙'); ?>
    <?php x1_nav_link('compatibility.php','Compatibilidade X1','≋'); ?>
    <?php x1_nav_link('logs.php','Logs API','≡'); ?>
    <?php x1_nav_link('api_test.php','Testes reais','⌁'); ?>
    <?php if(admin_can('security')) x1_nav_link('security.php','Segurança','◇'); ?>
    <?php if(admin_can('admins')) x1_nav_link('admins.php','Administradores','♙'); ?>
  </nav>
  <div class="sidebar-footer"><div class="admin-chip"><span class="admin-avatar"><?=h(strtoupper(substr((string)($me['username']??'A'),0,1)))?></span><div><strong><?=h($me['username']??'Admin')?></strong><small><?=h(strtoupper(admin_role($me)))?></small></div></div><div class="sidebar-footer-links"><a href="account.php">Conta</a><a href="logout.php">Sair</a></div></div>
</aside>
<main class="main-shell"><header class="topbar"><div class="page-title"><span class="eyebrow">X1 PANEL</span><h1><?=h($title)?></h1></div><div class="header-tools"><?=ui_lang_switcher()?><a class="top-action" href="diagnostics.php">Diagnóstico</a></div></header><div class="page-content"><?php } function bottom(): void { ?></div></main></body></html><?php } 