<?php
declare(strict_types=1); require_once __DIR__.'/../lib/bootstrap.php'; require_admin(); require_once __DIR__.'/_layout.php'; $cfg=config(); $app=$cfg['app']??[]; $saved=false; $themes=['d'=>'Standard','1'=>'Tema 1','2'=>'Tema 2','3'=>'Tema 3']; $languages=[ 'en'=>'English','ar'=>'العربية','bn'=>'বাংলা','zh'=>'中文','fr'=>'Français','hi'=>'हिन्दी', 'it'=>'Italiano','ml'=>'മലയാളം','pt'=>'Português','es'=>'Español','ru'=>'Русский','sv'=>'Svenska' ]; $groups=[ 'Live TV'=>['btn_live','btn_live2','btn_live3','btn_live4','btn_live5'], 'EPG'=>['btn_epg','btn_epg2','btn_epg3','btn_epg4','btn_epg5'], 'Filmes / VOD'=>['btn_vod','btn_vod2','btn_vod3','btn_vod4','btn_vod5'], 'Séries'=>['btn_series','btn_series2','btn_series3','btn_series4','btn_series5'], 'Catch-up'=>['btn_catchup','btn_catchup2','btn_catchup3','btn_catchup4','btn_catchup5'], 'Rádio'=>['btn_radio','btn_radio2','btn_radio3','btn_radio4','btn_radio5'], 'Multi-screen'=>['ms','ms2','ms3','ms4','ms5'], 'Favoritos'=>['btn_fav','btn_fav2','btn_fav3','btn_fav4','btn_fav5'], 'Conta'=>['btn_account','btn_account2','btn_account3','btn_account4','btn_account5'], ]; $single=[ 'btn_pr'=>'Controlo parental','btn_rec'=>'Gravação','btn_vpn'=>'VPN','btn_noti'=>'Notificações', 'btn_update'=>'Atualização','btn_login_settings'=>'Definições no login','btn_login_account'=>'Conta no login', 'btn_signup'=>'Registo','show_expire'=>'Mostrar expiração','settings_app'=>'Definições da app', 'settings_account'=>'Definições da conta','login_logo'=>'Logo no login','show_cat_count'=>'Contagem de categorias', 'load_last_channel'=>'Carregar último canal' ]; function x1_bool_value(string $key, bool $enabled, array $current): string { $old=(string)($current[$key]??''); $upper=in_array($old,['Yes','No'],true) || preg_match('/^btn_(live|epg|vod|series|radio|catchup)/',$key); return $enabled ? ($upper?'Yes':'yes') : ($upper?'No':'no'); } if($_SERVER['REQUEST_METHOD']==='POST'){ csrf_check(); $theme=(string)($_POST['theme']??'d'); if(!isset($themes[$theme]))$theme='d'; $lang=(string)($_POST['app_language']??'pt'); if(!isset($languages[$lang]))$lang='pt'; $secondary=(string)($_POST['language']??$lang); if(!isset($languages[$secondary]))$secondary=$lang; $app['theme']=$theme; $app['app_language']=$lang; $app['language']=$secondary; foreach($groups as $keys){ foreach($keys as $k)$app[$k]=x1_bool_value($k,isset($_POST[$k]),$app); } foreach($single as $k=>$label)$app[$k]=x1_bool_value($k,isset($_POST[$k]),$app); $cfg['app']=$app; save_config($cfg); $saved=true; } top('Personalizar APK X1'); if($saved)echo '<p class="ok">Personalização guardada. Tema, idioma e interface já foram sincronizados com <code>api/main.json</code> e serão enviados à APK no próximo pedido de licença.</p>'; ?>
<form method="post">
<input type="hidden" name="csrf" value="<?=csrf_token()?>">
<div class="card">
  <h2>Tema da APK</h2>
  <p class="small">Estes são os quatro códigos de tema existentes nesta build da APK. Seleciona visualmente; o painel grava o código técnico correto.</p>
  <div class="theme-picker">
  <?php foreach($themes as $code=>$label): ?>
    <label class="theme-option">
      <input type="radio" name="theme" value="<?=h($code)?>" <?=((string)($app['theme']??'d')===$code)?'checked':''?>>
      <span class="theme-frame"><img src="../assets/themes/<?=h($code)?>.jpg" alt="<?=h($label)?>"><strong><?=h($label)?></strong><small>Código: <?=h($code)?></small></span>
    </label>
  <?php endforeach; ?>
  </div>
</div>

<div class="card mt">
  <h2>Idioma</h2>
  <p class="small">O primeiro campo controla o idioma principal da aplicação. O segundo mantém compatibilidade com o campo <code>language</code> usado pela build original.</p>
  <div class="formgrid">
    <label class="field"><span>Idioma principal da APK</span><select name="app_language">
      <?php foreach($languages as $code=>$name):?><option value="<?=h($code)?>" <?=((string)($app['app_language']??'pt')===$code)?'selected':''?>><?=h($name)?> (<?=h($code)?>)</option><?php endforeach;?>
    </select></label>
    <label class="field"><span>Idioma secundário / compatibilidade</span><select name="language">
      <?php foreach($languages as $code=>$name):?><option value="<?=h($code)?>" <?=((string)($app['language']??'pt')===$code)?'selected':''?>><?=h($name)?> (<?=h($code)?>)</option><?php endforeach;?>
    </select></label>
  </div>
  <p><button class="btn secondary" type="button" id="sync-language">Usar o mesmo idioma nos dois campos</button></p>
</div>

<h2 class="sectiontitle">Menus e botões por portal</h2>
<div class="grid">
<?php foreach($groups as $name=>$keys):?>
  <div class="card"><h2><?=h($name)?></h2>
  <?php foreach($keys as $i=>$k):?><label class="toggle"><input type="checkbox" name="<?=h($k)?>" <?=strtolower((string)($app[$k]??''))==='yes'?'checked':''?>> Portal <?=$i+1?></label><?php endforeach;?>
  </div>
<?php endforeach;?>
<div class="card"><h2>Outras funções</h2><?php foreach($single as $k=>$label):?><label class="toggle"><input type="checkbox" name="<?=h($k)?>" <?=strtolower((string)($app[$k]??''))==='yes'?'checked':''?>> <?=h($label)?></label><?php endforeach;?></div>
</div>

<div class="sticky-save"><span>As alterações só entram em vigor depois de guardar.</span><button class="btn" type="submit">Guardar e enviar para a APK</button></div>
</form>
<script>
document.getElementById('sync-language').addEventListener('click',()=>{document.querySelector('[name=language]').value=document.querySelector('[name=app_language]').value;});
</script>
<?php bottom(); 