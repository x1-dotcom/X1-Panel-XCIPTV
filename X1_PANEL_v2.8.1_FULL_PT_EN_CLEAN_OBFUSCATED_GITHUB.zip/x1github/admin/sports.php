<?php
declare(strict_types=1); require_once __DIR__.'/../lib/bootstrap.php'; require_admin(); require_once __DIR__.'/_layout.php'; $s=store(); $saved=false; if($_SERVER['REQUEST_METHOD']==='POST'){ csrf_check(); $provider=(string)($_POST['provider']??'tvsportguide'); if(!in_array($provider,['tvsportguide','thesportsdb','custom'],true)) $provider='tvsportguide'; $apiKey=trim((string)($_POST['api_key']??'')); $s['sports']=[ 'provider'=>$provider, 'api_key'=>$apiKey, 'auto_s'=>$provider==='tvsportguide' ? $apiKey : trim((string)($_POST['auto_s']??($s['sports']['auto_s']??''))), 'custom_url'=>trim((string)($_POST['custom_url']??'')), 'sport'=>trim((string)($_POST['sport']??'Soccer')), 'header_n'=>trim((string)($_POST['header_n']??'Sports')), 'border_c'=>trim((string)($_POST['border_c']??'#222222')), 'background_c'=>trim((string)($_POST['background_c']??'#000000')), 'text_c'=>trim((string)($_POST['text_c']??'#ffffff')), 'days'=>max(1,min(14,(int)($_POST['days']??7))) ]; save_store($s); $saved=true; } $r=$s['sports']??[]; $provider=(string)($r['provider']??'tvsportguide'); $key=(string)($r['api_key']??($r['auto_s']??'')); top('Sports'); if($saved) echo '<p class="ok">Configuração de Sports guardada.</p>'; ?>
<div class="card">
<form method="post">
<input type="hidden" name="csrf" value="<?=h(csrf_token())?>">
<div class="formgrid">
<label class="field"><span>Provedor</span>
<select name="provider" id="provider">
<option value="tvsportguide" <?=$provider==='tvsportguide'?'selected':''?>>TVSportGuide (painel anterior)</option>
<option value="thesportsdb" <?=$provider==='thesportsdb'?'selected':''?>>TheSportsDB</option>
<option value="custom" <?=$provider==='custom'?'selected':''?>>URL / iframe personalizado</option>
</select></label>
<label class="field"><span>API key / Widget key</span><input name="api_key" value="<?=h($key)?>" autocomplete="off"></label>
<label class="field"><span>Desporto (TheSportsDB)</span><input name="sport" value="<?=h($r['sport']??'Soccer')?>" placeholder="Soccer"></label>
<label class="field"><span>URL personalizada</span><input name="custom_url" value="<?=h($r['custom_url']??'')?>" placeholder="https://..."></label>
<label class="field"><span>Cabeçalho</span><input name="header_n" value="<?=h($r['header_n']??'Sports')?>"></label>
<label class="field"><span>Cor da borda</span><input name="border_c" value="<?=h($r['border_c']??'#222222')?>"></label>
<label class="field"><span>Cor do fundo</span><input name="background_c" value="<?=h($r['background_c']??'#000000')?>"></label>
<label class="field"><span>Cor do texto</span><input name="text_c" value="<?=h($r['text_c']??'#ffffff')?>"></label>
<label class="field"><span>Dias a mostrar</span><input type="number" min="1" max="14" name="days" value="<?=h($r['days']??7)?>"></label>
</div>
<p><small><b>TVSportGuide:</b> coloca a parte da URL depois de <code>/widget/</code>. <b>TheSportsDB:</b> usa a tua API key; a chave pública de testes é <code>123</code>. <b>Personalizado:</b> coloca o URL completo da página/widget.</small></p>
<button class="btn">Guardar</button>
<a class="btn" href="../api/sport.php" target="_blank" rel="noopener">Pré-visualizar</a>
</form>
</div>
<?php bottom(); 