# X1 Panel v2.1 — APK Lab & Bulk Management

Esta versão acrescenta validação de entrega por dispositivo, gestão em massa e presets de perfis.

## Novidades v2.1

- **Laboratório APK X1**: regista cada entrega `licV3/licV4` por `userid`, fingerprint da configuração, tema, idioma, versão e perfil.
- **Callback após entrega**: cruza a hora da licença com o `connv2` posterior do mesmo dispositivo. Isto confirma comunicação servidor↔APK, mas não afirma que um tema foi visualmente renderizado no Android.
- **Gestão em massa de dispositivos**: pesquisa/filtros, seleção múltipla, Ativar, Bloquear, Perfil, Expiração e apagar histórico.
- **Presets de perfis**: Completo, Minimal, Só IPTV e Kids, todos criados como perfis editáveis.
- **Clonagem de perfis** para acelerar variantes por cliente/revenda.


Painel X1 para a APK XCIPTV 3004 v7.0 Panelled fornecida neste projeto.

## Identidade X1

- Marca administrativa: **X1**.
- Nome inicial da aplicação: **X1**.
- `customerid` inicial: **X1**.
- Logo oficial incluído em `assets/logo.png` e `api/logo.png`.
- Intro oficial incluída em `api/intro.mp4`.
- A página **Marca / Logo X1** sincroniza o logo do painel e o logo servido à APK.
- A página **Intro X1** permite pré-visualizar e substituir o vídeo.

## Requisitos

- PHP 8.1+
- OpenSSL
- escrita nas pastas `data/` e `api/`
- SQLite3 apenas para importar bases antigas pela ferramenta opcional de importação

## Instalação

1. Extrai o painel no servidor.
2. Dá permissão de escrita a `data/` e `api/`.
3. Abre `install.php` e cria o administrador.
4. Mantém acessíveis `api/ApiIPTV.php` e `api/CloudBackup.php` na rota utilizada pela APK.
5. No admin, usa **Compatibilidade X1** e **Testes reais** após a instalação.

## API implementada

`ApiIPTV.php` trata: `lic`, `licV3`, `licV4`, `man`, `connv2`, `conn`, `msg_conf`, `whatsup`, `gfilter`, `msg_cat_view`, `msg` e `vpnconfigV2`.

A atualização remota é entregue pelos campos `version_code`, `apkurl`, `backupurl` e `apkautoupdate` dentro da licença.

Outros componentes: `CloudBackup.php`, `movies.php`, `backdrop.php`, `movies_script.js`, `betstyle.css`, `sport.php`, `intro.mp4` e `logo.png`.

## Sports

O módulo permite escolher:

- TVSportGuide, com Widget/API key editável;
- TheSportsDB, com API key e desporto configuráveis;
- URL/iframe personalizado.

## Administração

Inclui Configurações gerais, Interface/Botões, VPN, Tema, TMDB, Intro X1, Sports, Players, Idioma, Anúncios, Mensagens, AdMob, PIN Parental, Manutenção, Atualização remota, Dispositivos, Marca/Logo X1, Cloud Backup, Importação de dados, Compatibilidade X1, Logs e Testes reais.

Consulta `VALIDATION.md` para saber o que foi efetivamente testado.

## Personalizar APK

A partir da v1.4, `admin/customize.php` concentra a personalização remota da APK:
- seleção visual entre Standard, Tema 1, Tema 2 e Tema 3;
- idioma principal e idioma secundário/compatibilidade;
- Live TV, EPG, Filmes/VOD, Séries, Catch-up, Rádio, Multi-screen, Favoritos e Conta por portal;
- VPN, gravação, parental, notificações, atualização, registo, logo no login e outras opções de interface.

As alterações são persistidas no `main.json` e enviadas à APK através do contrato de licença existente.

### Gestor de funcionalidades da APK
Em **Ativar / Desativar** é possível controlar as flags reais da build, incluindo menus por cada um dos cinco portais, conta/settings, VPN, gravação, notificações, mensagens, anúncios, publicidade e opções de player. O interruptor "Painel na APK" oculta as entradas relacionadas sem alterar o provider técnico `xtreamcodes`, que é o único valor observado no contrato original desta build.

## v1.6 — Dispositivos, licenças e perfis

- Gestão de acesso por `userid`: ACTIVE, BLOCKED, SUSPENDED e expiração automática.
- Notas e motivo de bloqueio por utilizador.
- Ações rápidas Bloquear/Ativar a partir da lista de dispositivos.
- Perfis por dispositivo com overrides seletivos da secção `app`.
- Um perfil pode alterar portais, nomes, tema, idioma, botões e qualquer chave real já suportada pelo X1.
- Sem perfil/regra, mantém-se a configuração global (compatibilidade retroativa).
- As regras são aplicadas a `licV3`, `licV4`, `connv2`, mensagens e VPN.

## X1 v1.7 — Operação e manutenção

Esta versão acrescenta três módulos de produção:

- **Backup do Painel X1**: exporta um ficheiro `.x1backup` com configuração, store completo, dispositivos, licenças, perfis, mensagens, VPN, TMDB/Sports, logs, logo e intro. O mesmo ficheiro pode ser restaurado pelo admin.
- **Logs e Auditoria**: filtros por tag/user/HTTP, exportação CSV e registo de ações administrativas críticas.
- **Atualização da APK**: aceita URL externo ou upload direto de `.apk`; ao fazer upload o painel publica a APK em `/uploads/x1-latest.apk`, atualiza `apkurl`, mantém `version_code` e calcula SHA-256.

O **Cloud Backup APK** continua separado do backup do próprio painel.

## X1 v1.8 — Operação, Segurança e Diagnóstico

- **Dashboard Operacional**: dispositivos realmente recentes, licenças bloqueadas/expiradas, chamadas/falhas API nas últimas 24h, taxa de erro, latência p95, estado da APK e módulos críticos.
- **Diagnóstico X1**: verifica PHP/OpenSSL/JSON, escrita em `data/`, sincronização de `main.json`, 117 parâmetros, endpoints/ficheiros auxiliares, logo, intro e estado da APK publicada. Inclui teste opcional de conectividade HTTP aos portais configurados.
- **Segurança do Admin**: CSRF no login e instalação, rate-limit persistente por utilizador+IP, bloqueio temporário configurável, timeout por inatividade, duração máxima de sessão, rotação do ID de sessão, cookies HttpOnly/SameSite=Strict e cabeçalhos anti-clickjacking/nosniff.
- **Auditoria de acesso**: login bem-sucedido/falhado/bloqueado, logout, alteração de password, alterações de política de segurança e testes de conectividade.

Os valores de segurança podem ser ajustados em **Segurança** sem editar PHP.

## X1 v1.9 — Equipa, Alertas e Manutenção Programada
- Perfis administrativos: Owner, Admin, Operador e Leitura.
- Contas podem ser ativadas/desativadas e ter password redefinida por Owner.
- Permissões são validadas no servidor, incluindo pedidos POST.
- Centro de Alertas X1 derivado do estado real do painel.
- Manutenção programada com início/fim e mensagem automática.
- O endpoint `man` e os blocos de manutenção de `licV3/licV4` usam o estado efetivo da janela programada.


## X1 v2.0
- Centro de notificações persistente.
- Health checks manuais e por cron autenticado por token, com histórico.
- Tarefas operacionais internas.
- Histórico de APK e rollback seguro com SHA-256/version code.

## X1 v2.2 — Editor visual de Perfis

Os perfis por dispositivo deixam de exigir edição manual de JSON. O módulo `admin/profiles.php` permite configurar visualmente:

- Tema Standard / 1 / 2 / 3 ou **Herdar**.
- Idioma principal e idioma de compatibilidade, com 12 idiomas da build.
- Overrides independentes dos 5 portais (nome + URL).
- Players de Live TV, VOD, Séries e Catch-up.
- Stream type e User-Agent.
- Menus por portal e funções gerais em três estados: **Herdar / Ativar / Desativar**.
- VAST, AdMob, Prebid, aceleração de hardware e legendas.
- Preview administrativo do perfil e contagem de overrides.
- Presets Completo, Minimal, Só IPTV e Kids, todos editáveis depois da criação.
- JSON avançado opcional apenas para campos não cobertos pelo editor visual.

O perfil continua a ser um overlay. Um campo em **Herdar** não é copiado para o perfil e continua a acompanhar a configuração global X1.

## v2.3 — Assistente de Migração X1
A migração passou a ter análise e aplicação separadas. O X1 reconhece a configuração principal, connv2, bases de VPN/mensagens/dispositivos/TMDB/Sports, intro e logos; mostra PRONTO / EM FALTA / CONFLITO / AÇÃO NECESSÁRIA; e cria automaticamente um `.x1backup` antes de aplicar qualquer alteração. ZIP requer `php-zip`; importação de SQLite requer `php-sqlite3`. Sem essas extensões, o painel identifica o que ficou pendente em vez de o marcar como importado.

## v2.4 — Hardening & Android Validation
Esta versão acrescenta 2FA/TOTP por administrador, restrição opcional por IP, auditoria com diff antes/depois e validação Android assistida dentro do Laboratório APK.

## v2.5 — Editor Visual da Home

O X1 inclui agora um editor visual da Home da APK. Permite selecionar o Portal 1–5, ver um preview administrativo e ligar/desligar os módulos reais suportados por cada portal, além de tema, idioma e funções globais. A página grava apenas campos existentes no contrato da APK. A ordem dos ícones é apresentada como ordem de preview e não é enviada à APK, porque esta build não expõe uma chave de ordenação conhecida.

## Interface bilingue / Bilingual interface

O X1 Panel inclui interface administrativa completa em **Português (PT)** e **English (EN)**. O seletor de idioma está disponível na instalação, login e painel administrativo, e a preferência mantém-se durante a navegação. A escolha do idioma do painel é independente do idioma configurado para a APK.

X1 Panel includes a complete administrative interface in **Portuguese (PT)** and **English (EN)**. The language selector is available during installation, login and throughout the admin panel, and the preference persists while browsing. The panel UI language is independent from the language configured for the APK.
