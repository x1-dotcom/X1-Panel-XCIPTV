<?php
require_once __DIR__.'/../lib/bootstrap.php'; json_response(['ok'=>true,'service'=>'X1 compatible API']); 