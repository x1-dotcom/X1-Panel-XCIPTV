# X1 Panel v2.5 — Editor Visual da Home

Data: 2026-08-18

## Implementado

- Nova página `admin/home_editor.php`.
- Preview visual da Home X1 por Portal 1–5.
- Tema Standard/1/2/3 ligado ao campo real `app.theme`.
- 12 idiomas suportados ligados a `app_language` e `language`.
- Ativação/desativação visual por portal de Live TV, EPG, Filmes, Séries, Catch-up, Rádio, Favoritos, Multi-screen e Conta.
- Ativação/desativação de VPN, Gravação, Parental, Notificações e Atualização.
- Gravação direta em `data/config.json` + sincronização para `api/main.json`.
- Auditoria before/after herdada do X1 v2.4.

## Teste funcional executado

Cenário de teste:

- Tema = `3`
- Idioma = `en`
- Portal 1: Live = ON, Filmes = ON, Favoritos = ON
- Portal 1: EPG/Séries/Catch-up/Rádio/Multi-screen/Conta = OFF
- VPN = ON
- Atualização = ON

Resultado:

- `data/config.json`: PASS
- `api/main.json`: PASS
- quantidade de chaves em `app`: 117/117
- pedido HTTP `licV3`: PASS
- AES decrypt do `licV3`: PASS
- valores desencriptados iguais aos escolhidos no editor: PASS

## Limitação deliberadamente indicada no UI

Esta build não expõe no contrato conhecido uma chave de ordenação dos ícones/botões da Home. Por isso o X1 v2.5 não afirma que consegue reordenar a Home nativa. O preview reflete visibilidade, tema e idioma; a ordem nativa continua a ser definida pela APK.

## Validação sintática

Todos os 50 ficheiros PHP passam `php -l`.
