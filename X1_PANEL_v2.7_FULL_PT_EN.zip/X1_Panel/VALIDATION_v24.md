# X1 Panel v2.4 — Hardening & Android Validation

## Novidades
- 2FA TOTP opcional por administrador.
- Restrição opcional de login por lista de IPs por administrador.
- Segundo passo de login apenas após password correta.
- Auditoria de alterações da configuração com diff campo/antes/depois.
- Exportação CSV de auditoria compatível com registos de diff.
- Laboratório APK com validação manual Android por `userid`.
- Checklist: Tema, Idioma, Menus, Portal, Players, VPN, Mensagem, Anúncio, Logo, Intro, Sports, TMDB, Update e Parental.
- Separação explícita entre: entregue pelo servidor, callback da APK e PASS/FAIL observado no Android.

## Validação executada
- `php -l` em 49 ficheiros PHP: PASS.
- Geração e validação TOTP RFC 6238: PASS.
- Login HTTP: password correta -> pedido 2FA: PASS.
- Login HTTP: TOTP válido -> sessão autenticada e redirect dashboard: PASS.
- Auditoria de alteração `app.theme`: diff com `before/after`: PASS.
- Estado do pacote antes de empacotar: 0 admins, 0 dispositivos, 0 licenças, 0 testes Android, 0 logs/auditoria.

## Nota importante
O Laboratório não transforma um callback em prova visual. Apenas um operador a observar a APK num Android pode marcar uma funcionalidade como PASS/FAIL visual.
