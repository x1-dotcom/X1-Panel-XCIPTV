# X1 Panel v2.0 — validação

## Implementado
- Centro de notificações persistente.
- Health checks locais manuais e via cron HTTP protegido por token.
- Histórico configurável de health checks.
- Tarefas operacionais internas.
- Histórico automático da APK antes de substituição.
- Rollback de APK com arquivo da versão atual antes do restauro.
- SHA-256, tamanho, version code e data em cada versão arquivada.
- Dashboard com notificações, tarefas e último health check.

## Testes executados localmente
- Instalação Owner: PASS.
- Login Owner: PASS.
- Health settings: PASS.
- Execução por endpoint cron autenticado: PASS.
- Histórico de health check: PASS.
- Centro de notificações autenticado: PASS.
- Criação de tarefa operacional: PASS.
- Upload APK A com version code 100: PASS.
- Upload APK B com version code 200: PASS.
- Arquivo automático da APK A com version code 100: PASS.
- Rollback B -> A: PASS.
- Conteúdo restaurado byte-a-byte: PASS.
- Version code restaurado para 100: PASS.
- Arquivo de B antes do rollback com version code 200: PASS.
- Notificações de upload e rollback: PASS.
- php -l em todos os ficheiros PHP: PASS.

Os utilizadores, APKs, tarefas, logs e notificações artificiais usados nos testes foram removidos antes do empacotamento.
