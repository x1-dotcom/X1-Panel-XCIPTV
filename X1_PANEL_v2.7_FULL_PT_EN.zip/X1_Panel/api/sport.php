<?php
declare(strict_types=1);
require_once __DIR__.'/../lib/bootstrap.php';

$s=store()['sports']??[];
$provider=(string)($s['provider']??'tvsportguide');
$key=trim((string)($s['api_key']??''));
if($key==='' && $provider==='tvsportguide') $key=trim((string)($s['auto_s']??''));
$heading=(string)($s['header_n']??'Sports');
$border=(string)($s['border_c']??'#222222');
$bg=(string)($s['background_c']??'#000000');
$text=(string)($s['text_c']??'#ffffff');
$days=max(1,min(14,(int)($s['days']??7)));

function sports_fetch_json(string $url): ?array {
    $body=false;
    if(function_exists('curl_init')){
        $ch=curl_init($url);
        curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_CONNECTTIMEOUT=>5,CURLOPT_TIMEOUT=>10,CURLOPT_USERAGENT=>'X1-Panel/1.1']);
        $body=curl_exec($ch);
        $code=(int)curl_getinfo($ch,CURLINFO_RESPONSE_CODE);
        curl_close($ch);
        if($body===false || $code<200 || $code>=300) return null;
    } elseif((bool)ini_get('allow_url_fopen')) {
        $ctx=stream_context_create(['http'=>['timeout'=>10,'user_agent'=>'X1-Panel/1.1']]);
        $body=@file_get_contents($url,false,$ctx);
        if($body===false) return null;
    } else return null;
    $json=json_decode((string)$body,true);
    return is_array($json)?$json:null;
}

function sports_safe_color(string $v,string $fallback): string {
    return preg_match('/^#[0-9a-fA-F]{6}$/',$v)?$v:$fallback;
}
$border=sports_safe_color($border,'#222222');
$bg=sports_safe_color($bg,'#000000');
$text=sports_safe_color($text,'#ffffff');

if($provider==='custom'){
    $url=trim((string)($s['custom_url']??''));
    if(!preg_match('#^https?://#i',$url)) $url='';
    ?><!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>html,body{margin:0;background:<?=h($bg)?>;height:100%;color:<?=h($text)?>;font-family:Arial,sans-serif}.err{padding:24px}iframe{display:block;border:0;height:100vh;width:100vw}</style></head><body><?php if($url===''):?><div class="err">Configura um URL válido no painel Sports.</div><?php else:?><iframe src="<?=h($url)?>" scrolling="auto" referrerpolicy="no-referrer-when-downgrade"></iframe><?php endif?></body></html><?php
    exit;
}

if($provider==='thesportsdb'){
    if($key==='') $key='123';
    $sport=trim((string)($s['sport']??'Soccer'));
    $events=[];$errors=0;
    for($i=0;$i<$days;$i++){
        $date=(new DateTimeImmutable('today'))->modify('+'.$i.' day')->format('Y-m-d');
        $url='https://www.thesportsdb.com/api/v1/json/'.rawurlencode($key).'/eventsday.php?d='.rawurlencode($date);
        if($sport!=='') $url.='&s='.rawurlencode($sport);
        $j=sports_fetch_json($url);
        if($j===null){$errors++;continue;}
        foreach(($j['events']??[]) as $e){if(is_array($e))$events[]=$e;}
    }
    usort($events,fn($a,$b)=>strcmp((string)($a['dateEvent']??'').' '.(string)($a['strTime']??''),(string)($b['dateEvent']??'').' '.(string)($b['strTime']??'')));
    ?><!doctype html><html lang="pt"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title><?=h($heading)?></title><style>
    *{box-sizing:border-box}body{margin:0;padding:16px;background:<?=h($bg)?>;color:<?=h($text)?>;font-family:Arial,sans-serif}h1{font-size:22px;margin:0 0 14px}.event{border:1px solid <?=h($border)?>;border-radius:10px;padding:12px;margin:0 0 10px}.date{opacity:.72;font-size:12px}.name{font-size:16px;font-weight:700;margin-top:4px}.meta{font-size:13px;opacity:.85;margin-top:4px}.empty{padding:20px;border:1px solid <?=h($border)?>;border-radius:10px}.provider{font-size:11px;opacity:.55;margin-top:16px}</style></head><body><h1><?=h($heading)?></h1>
    <?php if(!$events):?><div class="empty"><?= $errors===$days ? 'Não foi possível consultar o provedor.' : 'Sem eventos para o período selecionado.' ?></div><?php else:foreach($events as $e):
        $name=(string)($e['strEvent']??trim(((string)($e['strHomeTeam']??'')).' vs '.((string)($e['strAwayTeam']??''))));
        $league=(string)($e['strLeague']??'');$date=(string)($e['dateEvent']??'');$time=(string)($e['strTime']??'');
    ?><div class="event"><div class="date"><?=h(trim($date.' '.$time))?></div><div class="name"><?=h($name)?></div><?php if($league!==''):?><div class="meta"><?=h($league)?></div><?php endif?></div><?php endforeach;endif?>
    <div class="provider">Dados: TheSportsDB</div></body></html><?php
    exit;
}

// TVSportGuide: comportamento compatível com o painel anterior.
$id=rawurlencode($key);
$q=http_build_query(['filter_mode'=>'all','filter_value'=>'','days'=>$days,'heading'=>$heading,'border_color'=>'custom','autoscroll'=>1,'prev_nonce'=>'a7242d2019','custom_colors'=>ltrim($border,'#').','.ltrim($bg,'#').','.ltrim($text,'#')]);
$url='https://www.tvsportguide.com/widget/'.$id.'?'.$q;
?><!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1.0"><style>html,body{margin:0;background:<?=h($bg)?>;height:100%;color:<?=h($text)?>;font-family:Arial,sans-serif}.err{padding:24px}iframe{display:block;border:0;height:100vh;width:100vw}</style></head><body><?php if($key===''):?><div class="err">Configura a Widget key do TVSportGuide no painel Sports.</div><?php else:?><iframe src="<?=h($url)?>" scrolling="auto"></iframe><?php endif?></body></html>
