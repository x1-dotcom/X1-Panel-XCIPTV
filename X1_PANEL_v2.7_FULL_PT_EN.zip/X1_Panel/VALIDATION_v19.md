# X1 Panel v1.9 — validação

## Implementado
- Perfis administrativos: Owner, Admin, Operador e Leitura.
- Permissões validadas no servidor; contas Leitura recebem 403 em alterações POST.
- Gestão de administradores pelo Owner, com ativar/desativar, perfil e reset de password.
- Centro de Alertas X1 com falhas API, licenças expiradas, APK ausente, escrita de dados, OpenSSL e manutenção.
- Alertas podem ser dispensados e repostos.
- Manutenção programada com início/fim/mensagem.
- Estado efetivo aplicado a `man`, `licV4` e `licV3` durante a janela.
- Fora da janela, `licV3` sem userid continua a cifrar o `main.json` original diretamente.

## Testes executados localmente
- Login de conta Leitura: PASS.
- GET de configuração por Leitura: HTTP 200.
- Acesso de Leitura a Segurança: HTTP 403.
- POST de alteração por Leitura: HTTP 403.
- Centro de Alertas autenticado: HTTP 200.
- Manutenção programada ativa no endpoint `man`: PASS (`status=ACTIVE`, mensagem e fim corretos).
- Sintaxe PHP de todos os ficheiros: PASS.
