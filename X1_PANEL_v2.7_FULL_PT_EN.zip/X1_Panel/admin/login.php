<?php
declare(strict_types=1);
require_once __DIR__.'/../lib/bootstrap.php';
ensure_session();
if(is_admin()){header('Location:index.php');exit;}
$e='';$notice='';
if(!empty($_SESSION['session_expired'])){$notice='A sessão terminou por segurança. Inicia sessão novamente.';unset($_SESSION['session_expired']);}
$pending=null;if(!empty($_SESSION['pending_2fa']))$pending=find_row('admins','id',(string)$_SESSION['pending_2fa']);
if($_SERVER['REQUEST_METHOD']==='POST'){
 csrf_check();
 if(isset($_POST['cancel_2fa'])){unset($_SESSION['pending_2fa']);header('Location:login.php');exit;}
 if($pending){
  $code=trim((string)($_POST['totp']??''));
  if(!admin_ip_allowed($pending,client_ip())){$e='Este endereço IP não está autorizado para esta conta.';audit_log('login_ip_denied','username='.($pending['username']??''));unset($_SESSION['pending_2fa']);$pending=null;}
  elseif(totp_verify((string)($pending['totp_secret']??''),$code)){complete_admin_login($pending);audit_log('login_2fa_success','username='.($pending['username']??''));header('Location:index.php');exit;}
  else{$e='Código 2FA inválido.';audit_log('login_2fa_failed','username='.($pending['username']??''));}
 }else{
  prune_login_attempts();$username=trim((string)($_POST['username']??''));$ip=client_ip();$guard=login_guard($username,$ip);
  if(!$guard['allowed']){$mins=max(1,(int)ceil(($guard['locked_until']-time())/60));$e='Demasiadas tentativas. Tenta novamente dentro de '.$mins.' minuto(s).';audit_log('login_blocked','username='.$username.' ip='.$ip);}
  else{$r=find_row('admins','username',$username);
   if($r&&strtoupper((string)($r['status']??'ACTIVE'))!=='INACTIVE'&&password_verify((string)($_POST['password']??''),(string)$r['password_hash'])){
    if(!admin_ip_allowed($r,$ip)){$e='Este endereço IP não está autorizado para esta conta.';audit_log('login_ip_denied','username='.$username.' ip='.$ip);}
    elseif(!empty($r['totp_enabled'])&&!empty($r['totp_secret'])){login_clear_failures($username,$ip);$_SESSION['pending_2fa']=$r['id'];$_SESSION['csrf']=bin2hex(random_bytes(24));$pending=$r;audit_log('login_password_ok_2fa_required','username='.$username);}
    else{login_clear_failures($username,$ip);complete_admin_login($r);audit_log('login_success','username='.$username);header('Location:index.php');exit;}
   }else{$state=login_record_failure($username,$ip);audit_log('login_failed','username='.$username.' remaining='.$state['remaining']);if($state['locked']){$mins=max(1,(int)ceil(($state['locked_until']-time())/60));$e='Acesso temporariamente bloqueado após várias tentativas. Tenta novamente dentro de '.$mins.' minuto(s).';}else $e='Credenciais inválidas. Tentativas restantes: '.$state['remaining'].'.';}
  }
 }
}
?>
<!doctype html><html lang="<?=h(ui_lang())?>"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>X1 · Login</title><link rel="stylesheet" href="../assets/admin.css"><style>
body{display:grid;place-items:center;padding:24px}.login{width:min(460px,94vw);text-align:center;padding:28px}.login-logo{width:min(250px,72%);max-height:150px;object-fit:contain;border-radius:14px;filter:drop-shadow(0 0 22px rgba(34,239,255,.17))}.login form{text-align:left;margin-top:20px}.login .btn{width:100%;text-align:center}.community{margin-top:22px;padding-top:18px;border-top:1px solid rgba(34,239,255,.14)}.community-title{margin:0 0 11px;color:#a9d8e2;font-size:12px;letter-spacing:.08em;text-transform:uppercase}.community-links{display:grid;grid-template-columns:repeat(3,1fr);gap:9px}.community-link{display:flex;align-items:center;justify-content:center;gap:7px;min-height:42px;padding:9px 10px;border-radius:9px;text-decoration:none;color:#e9fbff;background:#071827;border:1px solid rgba(34,239,255,.18);font-weight:700}.login-foot{margin:14px 0 0;font-size:11px;color:#668f9d}@media(max-width:520px){.community-links{grid-template-columns:1fr}.login{padding:22px}}</style></head><body><div class="card login"><div style="display:flex;justify-content:flex-end;margin-bottom:8px"><?=ui_lang_switcher()?> </div>
<img class="login-logo" src="../assets/logo.png" alt="X1"><h1>X1</h1><p class="small">Administração segura</p><?php if($notice):?><p class="warn"><?=h($notice)?></p><?php endif?><?php if($e):?><p class="err"><?=h($e)?></p><?php endif?>
<?php if($pending):?><form method="post" autocomplete="one-time-code"><input type="hidden" name="csrf" value="<?=h(csrf_token())?>"><p><strong>2FA obrigatório</strong><br><span class="small">Introduz o código de 6 dígitos da app autenticadora para <?=h($pending['username']??'')?>.</span></p><label class="field"><span>Código TOTP</span><input name="totp" inputmode="numeric" autocomplete="one-time-code" pattern="[0-9]{6}" maxlength="6" autofocus required></label><button class="btn" type="submit">Confirmar 2FA</button><button class="btn secondary" type="submit" name="cancel_2fa" value="1">Cancelar</button></form>
<?php else:?><form method="post" autocomplete="on"><input type="hidden" name="csrf" value="<?=h(csrf_token())?>"><label class="field"><span>Utilizador</span><input name="username" autocomplete="username" required></label><label class="field"><span>Password</span><input type="password" name="password" autocomplete="current-password" required></label><button class="btn" type="submit">Entrar no X1</button></form><?php endif?>
<div class="community"><p class="community-title">Comunidade X1</p><div class="community-links"><a class="community-link" href="https://t.me/+XkuQS_QuD6g4Nzc0" target="_blank" rel="noopener noreferrer">Telegram</a><a class="community-link" href="https://forum.x1panel.space" target="_blank" rel="noopener noreferrer">Fórum</a><a class="community-link" href="https://discord.gg/vSSw6jHmw" target="_blank" rel="noopener noreferrer">Discord</a></div></div><p class="login-foot">X1 Panel · Comunidade &amp; suporte</p></div></body></html>
