<?php
function top(string $title): void { $me=current_admin();$alerts=count(x1_alerts()); ?><!doctype html><html lang="<?=h(ui_lang())?>"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title><?=h($title)?> · X1</title><link rel="stylesheet" href="../assets/admin.css"></head><body><aside><img src="../assets/logo.png"><b>X1</b><nav>
<a href="index.php">Dashboard</a>
<a href="alerts.php">Alertas X1<?= $alerts?' ('.$alerts.')':'' ?></a>
<a href="notifications.php">Notificações<?= unread_notifications()?' ('.unread_notifications().')':'' ?></a>
<a href="health.php">Health Checks</a>
<a href="ops_tasks.php">Tarefas Operacionais</a>
<a href="app.php">Configurações gerais</a>
<a href="customize.php">Personalizar APK</a>
<a href="home_editor.php">Editor visual da Home</a>
<a href="features.php">Ativar / Desativar</a>
<a href="interface.php">Interface / Botões</a>
<a href="vpn.php">VPN</a>
<a href="theme.php">Tema</a>
<a href="tmdb.php">TMDB</a>
<a href="intro.php">Intro X1</a>
<a href="sports.php">Sports</a>
<a href="players.php">Players</a>
<a href="language.php">Idioma</a>
<a href="announcements.php">Anúncio global</a>
<a href="messages.php">Mensagens</a>
<a href="appads.php">AdMob</a>
<a href="parental.php">PIN Parental</a>
<a href="maintenance.php">Manutenção</a>
<a href="updates.php">Atualização remota</a>
<a href="devices.php">Dispositivos</a>
<a href="apk_lab.php">Laboratório APK</a>
<a href="licenses.php">Licenças / Acesso</a>
<a href="profiles.php">Editor visual de Perfis</a>
<a href="logo.php">Marca / Logo X1</a>
<a href="backups.php">Cloud Backup APK</a>
<a href="panel_backup.php">Backup do Painel X1</a>
<a href="migration.php">Assistente de Migração</a>
<a href="compatibility.php">Compatibilidade X1</a>
<a href="logs.php">Logs API</a>
<a href="diagnostics.php">Diagnóstico X1</a>
<a href="api_test.php">Testes reais</a>
<?php if(admin_can('security')):?><a href="security.php">Segurança</a><?php endif?>
<?php if(admin_can('admins')):?><a href="admins.php">Administradores</a><?php endif?>
<a href="account.php">Conta Admin (<?=h(strtoupper(admin_role($me)))?>)</a>
<a href="logout.php">Sair</a></nav></aside><main><header><h1><?=h($title)?></h1><div class="header-tools"><?=ui_lang_switcher()?></div></header><?php }
function bottom(): void { ?></main></body></html><?php }
