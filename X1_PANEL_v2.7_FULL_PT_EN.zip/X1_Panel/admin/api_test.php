<?php
declare(strict_types=1);
require_once __DIR__.'/../lib/bootstrap.php';
require_admin();
require_once __DIR__.'/_layout.php';
$results=[];
function ft(string $url,array $post=[]):array{
    $start=microtime(true);
    $opts=['http'=>['timeout'=>8,'ignore_errors'=>true,'user_agent'=>'X1-SelfTest/1.0']];
    if($post){
        $opts['http']['method']='POST';
        $opts['http']['header']='Content-Type: application/x-www-form-urlencoded';
        $opts['http']['content']=http_build_query($post);
    }
    $body=@file_get_contents($url,false,stream_context_create($opts));
    $hs=$http_response_header??[];$code=0;
    if(isset($hs[0])&&preg_match('/\s(\d{3})\s/',$hs[0],$m))$code=(int)$m[1];
    return ['url'=>$url,'code'=>$code,'ms'=>(int)round((microtime(true)-$start)*1000),'body'=>$body===false?'Falha de ligação':(string)$body];
}
if($_SERVER['REQUEST_METHOD']==='POST'){
    csrf_check();$b=rtrim(base_url(),'/');$api=$b.'/api/ApiIPTV.php';$uid='selftest-x1';
    foreach([
        'licV3'=>'?tag=licV3',
        'licV4'=>'?tag=licV4&an=X1',
        'connv2'=>'?tag=connv2&userid='.$uid.'&appid=1878&version=911&device_type=test&p=test.pkg&an=X1&customerid=X1&online=yes&did=test-device',
        'conn'=>'?tag=conn','msg_conf'=>'?tag=msg_conf','whatsup'=>'?tag=whatsup','gfilter'=>'?tag=gfilter',
        'msg'=>'?tag=msg&userid='.$uid,'msg_cat_view'=>'?tag=msg_cat_view&userid='.$uid,
        'vpnconfigV2'=>'?tag=vpnconfigV2','man'=>'?tag=man'
    ] as $n=>$q)$results[$n]=ft($api.$q);
    $results['CloudBackup save']=ft($b.'/api/CloudBackup.php?user='.$uid.'&pass=testpass&backup=payload',['resetcode'=>'1234']);
    $results['CloudBackup restore']=ft($b.'/api/CloudBackup.php?user='.$uid.'&pass=testpass');
    $results['sport.php']=ft($b.'/api/sport.php');
    $results['movies.php']=ft($b.'/api/movies.php');
}
top('Testes reais');
?>
<div class=card><p>Executa HTTP real contra a instalação e cobre o contrato painel anterior.</p><form method=post><input type=hidden name=csrf value="<?=csrf_token()?>"><button class=btn>Executar suite</button></form></div>
<?php if($results):?>
<table><tr><th>Teste</th><th>HTTP</th><th>Tempo</th><th>Validação</th><th>Resposta</th></tr>
<?php foreach($results as $n=>$r): $valid=$r['code']>=200&&$r['code']<300&&$r['body']!==''; ?>
<tr><td><?=h($n)?></td><td><?=h($r['code'])?></td><td><?=h($r['ms'])?> ms</td><td><span class="badge <?=$valid?'active':'inactive'?>"><?=$valid?'OK':'FALHA'?></span></td><td><pre><?=h(substr($r['body'],0,500))?></pre></td></tr>
<?php endforeach?></table>
<?php endif; bottom(); ?>
