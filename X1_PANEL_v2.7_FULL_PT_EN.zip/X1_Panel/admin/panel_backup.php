<?php declare(strict_types=1);require_once __DIR__.'/../lib/bootstrap.php';require_admin();require_once __DIR__.'/_layout.php';
$msg='';$err='';
if(isset($_GET['download'])){audit_log('panel_backup_export','Backup completo do painel exportado');header('Content-Type: application/json');header('Content-Disposition: attachment; filename="X1-panel-backup-'.date('Ymd-His').'.x1backup"');echo x1_panel_backup_json();exit;}
if($_SERVER['REQUEST_METHOD']==='POST'){
 csrf_check();
 if(isset($_POST['restore'])){
  try{
   if(empty($_FILES['backup_file'])||($_FILES['backup_file']['error']??1)!==UPLOAD_ERR_OK)throw new RuntimeException('Seleciona um ficheiro .x1backup válido.');
   if((int)$_FILES['backup_file']['size']>25*1024*1024)throw new RuntimeException('Backup demasiado grande.');
   $raw=file_get_contents((string)$_FILES['backup_file']['tmp_name']);$b=json_decode((string)$raw,true);
   if(!is_array($b))throw new RuntimeException('O ficheiro não contém um backup X1 válido.');
   x1_restore_panel_backup($b);$msg='Backup restaurado com sucesso.';
  }catch(Throwable $e){$err=$e->getMessage();}
 }
}
top('Backup do Painel X1');if($msg)echo'<p class=ok>'.h($msg).'</p>';if($err)echo'<p class=err>'.h($err).'</p>';
?><div class=card><h2>Backup completo</h2><p>Exporta configuração X1, dispositivos, licenças, perfis, mensagens, VPN, TMDB/Sports, logs, logo e intro. Não inclui a APK enviada em Atualizações.</p><a class=btn href="?download=1">Descarregar backup X1</a></div>
<div class=card><h2>Restaurar</h2><p><strong>Atenção:</strong> substitui os dados atuais pelos dados presentes no backup.</p><form method=post enctype="multipart/form-data" onsubmit="return confirm('Restaurar este backup e substituir a configuração atual?')"><input type=hidden name=csrf value="<?=csrf_token()?>"><label class=field><span>Ficheiro .x1backup</span><input type=file name=backup_file accept=".x1backup,application/json" required></label><button class="btn danger" name=restore value=1>Restaurar backup</button></form></div><?php bottom();
