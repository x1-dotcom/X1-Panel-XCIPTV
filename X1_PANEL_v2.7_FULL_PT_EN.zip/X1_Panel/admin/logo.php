<?php declare(strict_types=1);
require_once __DIR__.'/../lib/bootstrap.php';require_admin();require_once __DIR__.'/_layout.php';
$msg='';$err='';
if($_SERVER['REQUEST_METHOD']==='POST'){
    csrf_check();
    [$ok,$m]=upload_asset('logo',PANEL_ROOT.'/api/logo.png',['png'],5*1024*1024);
    if($ok){
        if(!@copy(PANEL_ROOT.'/api/logo.png',PANEL_ROOT.'/assets/logo.png')){$err='Logo da APK guardado, mas não foi possível sincronizar o logo do painel.';}
        else{$msg='Marca X1 atualizada no painel e na APK.';}
    }else{$err=$m;}
}
top('Marca / Logo X1');
if($msg)echo'<p class=ok>'.h($msg).'</p>';if($err)echo'<p class=err>'.h($err).'</p>';
?><div class=card><p>Um único ficheiro atualiza os dois destinos: <code>assets/logo.png</code> (painel) e <code>api/logo.png</code> (APK).</p><?php if(is_file(PANEL_ROOT.'/api/logo.png')):?><img src="../api/logo.png?<?=time()?>" style="max-width:300px;max-height:180px"><?php endif?><form method=post enctype="multipart/form-data"><input type=hidden name=csrf value="<?=csrf_token()?>"><label class=field><span>Logo X1 (PNG)</span><input type=file name=logo accept="image/png" required></label><button class=btn>Atualizar marca X1</button></form></div><?php bottom();
