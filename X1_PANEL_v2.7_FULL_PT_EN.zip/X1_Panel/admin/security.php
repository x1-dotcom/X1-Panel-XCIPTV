<?php
declare(strict_types=1);
require_once __DIR__.'/../lib/bootstrap.php';require_admin();require_once __DIR__.'/_layout.php';
$msg='';$err='';$sec=security_config();
if($_SERVER['REQUEST_METHOD']==='POST'){
    csrf_check();
    if(isset($_POST['save_security'])){
        $new=[
            'max_attempts'=>max(3,min(20,(int)($_POST['max_attempts']??5))),
            'window_minutes'=>max(1,min(120,(int)($_POST['window_minutes']??15))),
            'lock_minutes'=>max(1,min(1440,(int)($_POST['lock_minutes']??15))),
            'idle_minutes'=>max(5,min(1440,(int)($_POST['idle_minutes']??30))),
            'absolute_hours'=>max(1,min(168,(int)($_POST['absolute_hours']??12))),
        ];
        save_security_config($new);$sec=security_config();audit_log('security_settings_update',json_encode($new));$msg='Definições de segurança atualizadas.';
    }
    if(isset($_POST['clear_blocks'])){setrows('login_attempts',[]);audit_log('login_blocks_clear','Todos os bloqueios/tentativas foram removidos');$msg='Tentativas e bloqueios de login limpos.';}
}
prune_login_attempts();$attempts=rows('login_attempts');$now=time();
top('Segurança do Admin');if($msg)echo '<p class=ok>'.h($msg).'</p>';if($err)echo '<p class=err>'.h($err).'</p>';
?>
<div class="grid">
 <div class="card"><div class="small">Sessão atual</div><div class="big">Ativa</div><p class="small">Utilizador: <?=h($_SESSION['admin_user']??'')?> · iniciada <?=h(date('Y-m-d H:i',(int)($_SESSION['auth_started']??time())))?></p></div>
 <div class="card"><div class="small">Tentativas registadas</div><div class="big"><?=count($attempts)?></div><p class="small">Rate-limit persistente por utilizador + IP.</p></div>
 <div class="card"><div class="small">Bloqueios ativos</div><div class="big"><?=count(array_filter($attempts,fn($r)=>(int)($r['locked_until']??0)>$now))?></div><p class="small">Bloqueios desaparecem automaticamente após o período configurado.</p></div>
</div>
<div class="card mt"><h2>Política de acesso</h2><form method="post"><input type="hidden" name="csrf" value="<?=h(csrf_token())?>"><div class="formgrid">
<label class="field"><span>Tentativas máximas</span><input type="number" name="max_attempts" min="3" max="20" value="<?=h($sec['max_attempts'])?>"></label>
<label class="field"><span>Janela de tentativas (min)</span><input type="number" name="window_minutes" min="1" max="120" value="<?=h($sec['window_minutes'])?>"></label>
<label class="field"><span>Bloqueio após limite (min)</span><input type="number" name="lock_minutes" min="1" max="1440" value="<?=h($sec['lock_minutes'])?>"></label>
<label class="field"><span>Timeout por inatividade (min)</span><input type="number" name="idle_minutes" min="5" max="1440" value="<?=h($sec['idle_minutes'])?>"></label>
<label class="field"><span>Duração máxima da sessão (h)</span><input type="number" name="absolute_hours" min="1" max="168" value="<?=h($sec['absolute_hours'])?>"></label>
</div><p><button class="btn" name="save_security">Guardar segurança</button></p></form></div>
<div class="card mt"><h2>Tentativas / bloqueios</h2><form method="post" onsubmit="return confirm('Limpar todas as tentativas e bloqueios?')"><input type="hidden" name="csrf" value="<?=h(csrf_token())?>"><button class="btn danger" name="clear_blocks">Limpar bloqueios</button></form></div>
<table><tr><th>Utilizador</th><th>IP</th><th>Tentativas na janela</th><th>Bloqueado até</th><th>Atualizado</th></tr>
<?php foreach(array_reverse($attempts) as $r):?><tr><td><?=h($r['username']??'')?></td><td><?=h($r['ip']??'')?></td><td><?=count((array)($r['attempts']??[]))?></td><td><?php $lu=(int)($r['locked_until']??0);echo $lu>$now?h(date('Y-m-d H:i:s',$lu)):'—';?></td><td><?=h($r['updated_at']??'')?></td></tr><?php endforeach?>
</table>
<div class="card mt"><h2>Proteções ativas</h2><p class="small">Cookies de sessão HttpOnly + SameSite=Strict, Secure quando HTTPS está ativo, rotação do ID após login, CSRF em operações administrativas, timeout por inatividade, duração máxima de sessão, rate-limit persistente e cabeçalhos anti-clickjacking/nosniff.</p></div>
<?php bottom();
