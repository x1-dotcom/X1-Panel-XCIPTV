<?php
declare(strict_types=1);require_once __DIR__.'/../lib/bootstrap.php';require_admin();require_once __DIR__.'/_layout.php';
$msg='';$err='';$me=current_admin();
if($_SERVER['REQUEST_METHOD']==='POST'){
 csrf_check();$action=(string)($_POST['action']??'save');
 if($action==='delete'){
  $id=(string)($_POST['id']??'');$r=find_row('admins','id',$id);
  if(!$r)$err='Conta não encontrada.';
  elseif((string)($r['id']??'')===(string)($_SESSION['admin_id']??''))$err='Não podes apagar a conta com sessão ativa.';
  else{$owners=array_values(array_filter(rows('admins'),fn($x)=>admin_role($x)==='owner'&&strtoupper((string)($x['status']??'ACTIVE'))!=='INACTIVE'));if(admin_role($r)==='owner'&&count($owners)<=1)$err='Tem de existir pelo menos um Owner ativo.';else{delete_row('admins','id',$id);audit_log('admin_delete','username='.($r['username']??''));$msg='Administrador removido.';}}
 } else {
  $id=trim((string)($_POST['id']??''));$username=trim((string)($_POST['username']??''));$name=trim((string)($_POST['display_name']??''));$role=(string)($_POST['role']??'viewer');$status=(string)($_POST['status']??'ACTIVE');$pass=(string)($_POST['password']??'');$allowedIps=trim((string)($_POST['allowed_ips']??''));$totpAction=(string)($_POST['totp_action']??'keep');
  if(strlen($username)<3)$err='Utilizador precisa de pelo menos 3 caracteres.';
  elseif(!in_array($role,['owner','admin','operator','viewer'],true))$err='Perfil inválido.';
  elseif($id===''&&strlen($pass)<10)$err='Password inicial: mínimo 10 caracteres.';
  elseif(($other=find_row('admins','username',$username))&&($id===''||(string)$other['id']!==$id))$err='Esse utilizador já existe.';
  else{
   $old=$id!==''?find_row('admins','id',$id):null;
   if($old&&admin_role($old)==='owner'&&$role!=='owner'){$owners=array_values(array_filter(rows('admins'),fn($x)=>admin_role($x)==='owner'&&strtoupper((string)($x['status']??'ACTIVE'))!=='INACTIVE'));if(count($owners)<=1)$err='Não podes remover o último Owner.';}
   if(!$err){$row=['username'=>$username,'display_name'=>$name?:$username,'role'=>$role,'status'=>$status==='INACTIVE'?'INACTIVE':'ACTIVE','allowed_ips'=>$allowedIps,'updated_at'=>now()];if($old)$row=array_merge($old,$row);else{$row['created_at']=now();$row['password_hash']=password_hash($pass,PASSWORD_DEFAULT);}if($pass!==''){$row['password_hash']=password_hash($pass,PASSWORD_DEFAULT);}if($totpAction==='enable'){if(empty($row['totp_secret']))$row['totp_secret']=totp_secret();$row['totp_enabled']=true;}elseif($totpAction==='disable'){$row['totp_enabled']=false;$row['totp_secret']='';}$saved=upsert_row('admins',$id!==''?'id':'username',$id!==''?$id:$username,$row);audit_log($old?'admin_update':'admin_create','username='.$username.' role='.$role);$msg='Conta guardada.';}
  }
 }
}
$edit=null;if(isset($_GET['edit']))$edit=find_row('admins','id',(string)$_GET['edit']);top('Administradores X1');if($msg)echo'<p class=ok>'.h($msg).'</p>';if($err)echo'<p class=err>'.h($err).'</p>';
?>
<div class="card"><h2><?= $edit?'Editar administrador':'Novo administrador' ?></h2><form method="post"><input type="hidden" name="csrf" value="<?=h(csrf_token())?>"><input type="hidden" name="id" value="<?=h($edit['id']??'')?>"><div class="formgrid">
<label class="field"><span>Nome</span><input name="display_name" value="<?=h($edit['display_name']??'')?>"></label>
<label class="field"><span>Utilizador</span><input name="username" required value="<?=h($edit['username']??'')?>"></label>
<label class="field"><span>Perfil</span><select name="role"><?php foreach(['owner'=>'Owner','admin'=>'Admin','operator'=>'Operador','viewer'=>'Leitura'] as $v=>$n):?><option value="<?=$v?>" <?=($edit['role']??'')===$v?'selected':''?>><?=$n?></option><?php endforeach?></select></label>
<label class="field"><span>Estado</span><select name="status"><option>ACTIVE</option><option <?=($edit['status']??'ACTIVE')==='INACTIVE'?'selected':''?>>INACTIVE</option></select></label>
<label class="field"><span><?= $edit?'Nova password (opcional)':'Password inicial' ?></span><input type="password" name="password" <?= $edit?'':'required' ?> minlength="10"></label>
<label class="field"><span>IPs autorizados (opcional)</span><textarea name="allowed_ips" rows="3" placeholder="203.0.113.10, 198.51.100.20"><?=h($edit['allowed_ips']??'')?></textarea></label>
<label class="field"><span>2FA / TOTP</span><select name="totp_action"><option value="keep">Manter como está</option><option value="enable">Ativar / gerar segredo</option><option value="disable">Desativar</option></select></label>
</div><?php if($edit&&!empty($edit['totp_enabled'])&&!empty($edit['totp_secret'])):$uri='otpauth://totp/'.rawurlencode('X1:'.($edit['username']??'' )).'?secret='.rawurlencode((string)$edit['totp_secret']).'&issuer='.rawurlencode('X1 Panel').'&digits=6&period=30';?><div class="card" style="margin-top:12px"><strong>2FA ativo</strong><p class="small">Segredo TOTP: <code><?=h($edit['totp_secret'])?></code></p><p class="small">URI para app autenticadora:</p><textarea rows="3" readonly><?=h($uri)?></textarea><p class="small">Guarda este segredo num local seguro. Desativar e voltar a ativar gera um novo segredo.</p></div><?php endif?><p class="small">Owner: acesso total. Admin: tudo exceto gestão de administradores. Operador: operação/configuração sem segurança/backups. Leitura: consulta sem alterações.</p><button class="btn">Guardar conta</button></form></div>
<div class="card mt"><h2>Contas</h2><table><tr><th>Nome</th><th>Utilizador</th><th>Perfil</th><th>Estado</th><th>2FA</th><th>IPs</th><th>Criada</th><th>Ações</th></tr><?php foreach(rows('admins') as $r):?><tr><td><?=h($r['display_name']??$r['username']??'')?></td><td><?=h($r['username']??'')?></td><td><span class="badge active"><?=h(strtoupper(admin_role($r)))?></span></td><td><span class="badge <?=strtoupper((string)($r['status']??'ACTIVE'))==='ACTIVE'?'active':'inactive'?>"><?=h($r['status']??'ACTIVE')?></span></td><td><?=!empty($r['totp_enabled'])?'<span class="badge active">ON</span>':'<span class="badge inactive">OFF</span>'?></td><td><?=h(trim((string)($r['allowed_ips']??''))!==''?'Restrito':'Qualquer')?></td><td><?=h($r['created_at']??'')?></td><td class="actions"><a class="btn secondary" href="?edit=<?=urlencode((string)$r['id'])?>">Editar</a><?php if((string)($r['id']??'')!==(string)($_SESSION['admin_id']??'')):?><form method="post" onsubmit="return confirm('Remover esta conta?')"><input type="hidden" name="csrf" value="<?=h(csrf_token())?>"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?=h($r['id']??'')?>"><button class="btn danger">Apagar</button></form><?php endif?></td></tr><?php endforeach?></table></div>
<?php bottom();
