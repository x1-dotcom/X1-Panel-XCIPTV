<?php
declare(strict_types=1);
require_once __DIR__.'/../lib/bootstrap.php';require_admin();require_once __DIR__.'/_layout.php';
function dcheck(string $name,bool $ok,string $detail='',string $level='critical'):array{return compact('name','ok','detail','level');}
function url_probe(string $url):array{
    if(!preg_match('#^https?://#i',$url))return ['ok'=>false,'code'=>0,'ms'=>0,'detail'=>'URL não HTTP(S)'];
    $start=microtime(true);$code=0;$err='';
    if(function_exists('curl_init')){$ch=curl_init($url);curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_NOBODY=>true,CURLOPT_FOLLOWLOCATION=>true,CURLOPT_MAXREDIRS=>3,CURLOPT_CONNECTTIMEOUT=>4,CURLOPT_TIMEOUT=>6,CURLOPT_USERAGENT=>'X1-Diagnostics/1.0']);curl_exec($ch);$code=(int)curl_getinfo($ch,CURLINFO_RESPONSE_CODE);$err=(string)curl_error($ch);curl_close($ch);}
    else{$ctx=stream_context_create(['http'=>['method'=>'HEAD','timeout'=>6,'ignore_errors'=>true,'user_agent'=>'X1-Diagnostics/1.0']]);@file_get_contents($url,false,$ctx);$hs=$http_response_header??[];if(isset($hs[0])&&preg_match('/\s(\d{3})\s/',$hs[0],$m))$code=(int)$m[1];if(!$code)$err='Sem resposta HTTP';}
    return ['ok'=>$code>=200&&$code<500,'code'=>$code,'ms'=>(int)round((microtime(true)-$start)*1000),'detail'=>$err];
}
$c=config();$app=$c['app']??[];$checks=[];
$checks[]=dcheck('PHP 8.1+',version_compare(PHP_VERSION,'8.1.0','>='),PHP_VERSION);
$checks[]=dcheck('OpenSSL',extension_loaded('openssl'),extension_loaded('openssl')?'carregado':'extensão em falta');
$checks[]=dcheck('JSON',extension_loaded('json'),'extensão JSON');
$checks[]=dcheck('Diretório data gravável',is_dir(DATA_DIR)&&is_writable(DATA_DIR),DATA_DIR);
$checks[]=dcheck('config.json válido',is_file(CONFIG_FILE)&&is_array(jread(CONFIG_FILE,[])),CONFIG_FILE);
$checks[]=dcheck('store.json válido',is_file(STORE_FILE)&&is_array(jread(STORE_FILE,[])),STORE_FILE);
$checks[]=dcheck('main.json sincronizado',jread(PANEL_ROOT.'/api/main.json',[])===['tag'=>$c['tag']??'licV3','success'=>$c['success']??'1','api_ver'=>$c['api_ver']??'2.0v','which'=>$c['which']??'licV3','app'=>$app],'api/main.json');
$checks[]=dcheck('117 parâmetros base',count($app)===117,'Encontrados: '.count($app),'warning');
foreach(['api/ApiIPTV.php','api/CloudBackup.php','api/sport.php','api/movies.php','api/backdrop.php'] as $f)$checks[]=dcheck($f,is_file(PANEL_ROOT.'/'.$f),is_file(PANEL_ROOT.'/'.$f)?'presente':'em falta');
$checks[]=dcheck('Logo X1',is_file(PANEL_ROOT.'/api/logo.png')&&filesize(PANEL_ROOT.'/api/logo.png')>0,'api/logo.png','warning');
$checks[]=dcheck('Intro X1',is_file(PANEL_ROOT.'/api/intro.mp4')&&filesize(PANEL_ROOT.'/api/intro.mp4')>0,is_file(PANEL_ROOT.'/api/intro.mp4')?number_format(filesize(PANEL_ROOT.'/api/intro.mp4')/1024/1024,1).' MB':'em falta','warning');
$apk=PANEL_ROOT.'/uploads/x1-latest.apk';$apkLocal=is_file($apk)&&filesize($apk)>0;$apkUrl=(string)($app['apkurl']??'');
$checks[]=dcheck('APK publicada',$apkLocal,$apkLocal?number_format(filesize($apk)/1024/1024,1).' MB · SHA-256 '.substr(hash_file('sha256',$apk),0,16).'…':'Nenhuma APK local publicada','warning');
$checks[]=dcheck('URL de atualização',trim($apkUrl)!=='',$apkUrl?:'não configurada','warning');
$logs=rows('logs');$cut=time()-86400;$recent=array_values(array_filter($logs,fn($x)=>strtotime((string)($x['created_at']??'1970-01-01'))>=$cut));$fail=array_values(array_filter($recent,fn($x)=>(int)($x['http_status']??0)>=400||in_array(strtoupper((string)($x['success']??'')),['0','FALSE','FAIL','ERROR'],true)));$dur=array_map(fn($x)=>(int)($x['duration_ms']??0),$recent);sort($dur);$p95=$dur?($dur[(int)floor((count($dur)-1)*.95)]??0):0;$last=$logs?end($logs):null;
$external=[];
if($_SERVER['REQUEST_METHOD']==='POST'&&isset($_POST['probe'])){csrf_check();foreach(range(1,5) as $i){$k=$i===1?'portal':'portal'.$i;$url=trim((string)($app[$k]??''));if($url!==''&&$url!=='0')$external[$k]=array_merge(['url'=>$url],url_probe($url));}audit_log('diagnostics_probe','Portais testados: '.count($external));}
$criticalFail=count(array_filter($checks,fn($x)=>!$x['ok']&&$x['level']==='critical'));$warningFail=count(array_filter($checks,fn($x)=>!$x['ok']&&$x['level']!=='critical'));
top('Diagnóstico X1');
?>
<div class="grid">
<div class="card"><div class="small">Estado geral</div><div class="big"><?=$criticalFail===0?'OK':'FALHA'?></div><p class="small"><?=h($criticalFail>0 ? $criticalFail.' falha(s) crítica(s)' : 'Sem falhas críticas')?></p></div>
<div class="card"><div class="small">Avisos</div><div class="big"><?=$warningFail?></div><p class="small">Itens não críticos que merecem atenção.</p></div>
<div class="card"><div class="small">Chamadas API · 24h</div><div class="big"><?=count($recent)?></div><p class="small">Falhas: <?=count($fail)?> · erro <?=count($recent)?number_format(count($fail)*100/count($recent),1):'0.0'?>%</p></div>
<div class="card"><div class="small">Latência p95 · 24h</div><div class="big"><?=$p95?> ms</div><p class="small">Última chamada: <?=h($last['created_at']??'sem dados')?></p></div>
</div>
<div class="card mt"><h2>Saúde local</h2><table><tr><th>Componente</th><th>Estado</th><th>Detalhe</th></tr><?php foreach($checks as $x):?><tr><td><?=h($x['name'])?></td><td><span class="badge <?=$x['ok']?'active':'inactive'?>"><?=$x['ok']?'OK':($x['level']==='critical'?'FALHA':'AVISO')?></span></td><td><?=h($x['detail'])?></td></tr><?php endforeach?></table></div>
<div class="card mt"><h2>Portais configurados</h2><p class="small">O teste externo faz apenas uma ligação HTTP curta. Não altera utilizadores nem configurações.</p><form method="post"><input type="hidden" name="csrf" value="<?=h(csrf_token())?>"><button class="btn" name="probe">Testar conectividade dos portais</button></form>
<?php if($external):?><table><tr><th>Portal</th><th>URL</th><th>HTTP</th><th>Tempo</th><th>Estado</th></tr><?php foreach($external as $k=>$r):?><tr><td><?=h($k)?></td><td><?=h($r['url'])?></td><td><?=h($r['code'])?></td><td><?=h($r['ms'])?> ms</td><td><span class="badge <?=$r['ok']?'active':'inactive'?>"><?=$r['ok']?'ALCANÇÁVEL':'FALHA'?></span> <?=h($r['detail'])?></td></tr><?php endforeach?></table><?php endif?></div>
<div class="card mt"><h2>Atualização APK</h2><p><b>Version code:</b> <?=h($app['version_code']??'')?> · <b>Auto update:</b> <?=h($app['apkautoupdate']??'')?></p><p><b>URL:</b> <code><?=h($apkUrl)?></code></p><?php if($apkLocal):?><p><b>APK local:</b> <?=h(number_format(filesize($apk)/1024/1024,2))?> MB · <code><?=h(hash_file('sha256',$apk))?></code></p><?php endif?></div>
<?php bottom();
