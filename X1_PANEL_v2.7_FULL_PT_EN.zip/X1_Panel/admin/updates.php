<?php declare(strict_types=1);require_once __DIR__.'/../lib/bootstrap.php';require_admin();require_once __DIR__.'/_layout.php';
$c=config();$saved=false;$msg='';$err='';$apkDir=PANEL_ROOT.'/uploads';$apkFile=$apkDir.'/x1-latest.apk';if(!is_dir($apkDir))@mkdir($apkDir,0775,true);
if($_SERVER['REQUEST_METHOD']==='POST'){
 csrf_check();
 try{
  $action=(string)($_POST['action']??'save');
  if($action==='rollback'){
   $id=(string)($_POST['version_id']??'');$ver=find_row('apk_versions','id',$id);if(!$ver)throw new RuntimeException('Versão não encontrada.');$src=PANEL_ROOT.'/'.ltrim((string)($ver['file']??''),'/');if(!is_file($src))throw new RuntimeException('Ficheiro arquivado em falta.');
   archive_current_apk('antes do rollback');if(!copy($src,$apkFile))throw new RuntimeException('Não foi possível restaurar a APK.');
   $c['app']['version_code']=(string)($ver['version_code']??$c['app']['version_code']??'');$c['app']['apkurl']=base_url().'/uploads/x1-latest.apk';save_config($c);audit_log('apk_rollback','id='.$id.' version_code='.$c['app']['version_code']);notify('apk','Rollback da APK concluído','Version code '.$c['app']['version_code'],'warn');$saved=true;$msg='Rollback concluído.';
  }else{
   $hasUpload=!empty($_FILES['apk_file'])&&($_FILES['apk_file']['error']??UPLOAD_ERR_NO_FILE)!==UPLOAD_ERR_NO_FILE;
   if($hasUpload)archive_current_apk('substituída por upload');
   foreach(['version_code','apkurl','backupurl','apkautoupdate'] as $f)$c['app'][$f]=trim((string)($_POST[$f]??($c['app'][$f]??'')));
   if($hasUpload){
    $f=$_FILES['apk_file'];if(($f['error']??1)!==UPLOAD_ERR_OK)throw new RuntimeException('Falha no upload da APK.');if((int)$f['size']>300*1024*1024)throw new RuntimeException('APK superior a 300 MB.');if(strtolower(pathinfo((string)$f['name'],PATHINFO_EXTENSION))!=='apk')throw new RuntimeException('O ficheiro tem de ser .apk.');
    if(!move_uploaded_file((string)$f['tmp_name'],$apkFile))throw new RuntimeException('Não foi possível guardar a APK.');$c['app']['apkurl']=base_url().'/uploads/x1-latest.apk';$sha=hash_file('sha256',$apkFile);notify('apk','Nova APK publicada','Version code '.(string)$c['app']['version_code'].' · '.substr($sha,0,12).'…','info');$msg='APK enviada e versão anterior arquivada. ';
   }
   save_config($c);audit_log('apk_update_config','version_code='.(string)($c['app']['version_code']??'').' apkurl='.(string)($c['app']['apkurl']??''));$saved=true;$msg.='Configuração de atualização guardada.';
  }
 }catch(Throwable $e){$err=$e->getMessage();}
}
$versions=array_reverse(apk_versions());top('Atualização da APK');if($saved)echo'<p class=ok>'.h($msg).'</p>';if($err)echo'<p class=err>'.h($err).'</p>';
?><div class=card><p>Os valores são entregues à APK pela licença. Um upload arquiva automaticamente a APK anterior para permitir rollback.</p><form method=post enctype="multipart/form-data"><input type=hidden name=csrf value="<?=csrf_token()?>"><input type=hidden name=action value=save><div class=formgrid>
<label class=field><span>Version code</span><input name=version_code value="<?=h($c['app']['version_code']??'')?>"></label>
<label class=field><span>Auto update</span><select name=apkautoupdate><option value=yes <?=strtolower((string)($c['app']['apkautoupdate']??''))==='yes'?'selected':''?>>yes</option><option value=no <?=strtolower((string)($c['app']['apkautoupdate']??''))==='no'?'selected':''?>>no</option></select></label>
<label class=field style="grid-column:1/-1"><span>URL da APK</span><input name=apkurl value="<?=h($c['app']['apkurl']??'')?>"></label>
<label class=field style="grid-column:1/-1"><span>Backup URL</span><input name=backupurl value="<?=h($c['app']['backupurl']??'')?>"></label>
<label class=field style="grid-column:1/-1"><span>Ou enviar APK</span><input type=file name=apk_file accept=".apk,application/vnd.android.package-archive"></label>
</div><button class=btn>Guardar / Enviar</button></form></div>
<?php if(is_file($apkFile)):?><div class=card><h2>APK atual</h2><p>Tamanho: <?=h(number_format(filesize($apkFile)/1024/1024,2))?> MB · SHA-256: <code><?=h(hash_file('sha256',$apkFile))?></code></p><p><a class=btn href="../uploads/x1-latest.apk" target=_blank rel=noopener>Abrir APK atual</a></p></div><?php endif;?>
<div class="card mt"><h2>Histórico / Rollback</h2><?php if(!$versions):?><p class=small>Ainda não há versões arquivadas. O histórico começa no próximo upload/substituição.</p><?php else:?><table><tr><th>Data</th><th>Version code</th><th>Tamanho</th><th>SHA-256</th><th>Nota</th><th></th></tr><?php foreach($versions as $v):?><tr><td><?=h($v['created_at']??'')?></td><td><?=h($v['version_code']??'')?></td><td><?=h(number_format(((int)($v['size']??0))/1024/1024,2))?> MB</td><td><code><?=h(substr((string)($v['sha256']??''),0,16))?>…</code></td><td><?=h($v['label']??'')?></td><td><form method=post onsubmit="return confirm('Restaurar esta APK? A atual será arquivada primeiro.')"><input type=hidden name=csrf value="<?=h(csrf_token())?>"><input type=hidden name=action value=rollback><input type=hidden name=version_id value="<?=h($v['id']??'')?>"><button class="btn secondary">Rollback</button></form></td></tr><?php endforeach?></table><?php endif?></div><?php bottom();
