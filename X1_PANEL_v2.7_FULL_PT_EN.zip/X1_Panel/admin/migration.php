<?php
declare(strict_types=1);
require_once __DIR__.'/../lib/bootstrap.php';
require_admin();
require_once __DIR__.'/_layout.php';

const X1MIG_STAGE = DATA_DIR.'/migration_stage';
@mkdir(X1MIG_STAGE,0775,true);

function x1mig_clear():void{
  if(!is_dir(X1MIG_STAGE)) return;
  $it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator(X1MIG_STAGE,FilesystemIterator::SKIP_DOTS),RecursiveIteratorIterator::CHILD_FIRST);
  foreach($it as $f){$p=$f->getPathname();$f->isDir()?@rmdir($p):@unlink($p);} 
}
function x1mig_rel(string $n):string{
  $n=str_replace('\\','/',$n);$out=[];
  foreach(explode('/',$n) as $p){if($p===''||$p==='.'||$p==='..')continue;$out[]=preg_replace('/[^A-Za-z0-9._ -]/','_',basename($p));}
  return implode('/',$out);
}
function x1mig_upload():array{
  x1mig_clear();$saved=[];
  if(!empty($_FILES['source_zip'])&&($_FILES['source_zip']['error']??1)===UPLOAD_ERR_OK){
    if(!class_exists('ZipArchive')) throw new RuntimeException('php-zip não está instalado. Usa a seleção de pasta/ficheiros.');
    $z=new ZipArchive();if($z->open((string)$_FILES['source_zip']['tmp_name'])!==true)throw new RuntimeException('ZIP inválido.');
    for($i=0;$i<$z->numFiles;$i++){$st=$z->statIndex($i);$raw=(string)($st['name']??'');if(str_ends_with($raw,'/'))continue;$rel=x1mig_rel($raw);if($rel==='')continue;$dst=X1MIG_STAGE.'/'.$rel;@mkdir(dirname($dst),0775,true);$src=$z->getStream($raw);if(!$src)continue;$o=fopen($dst,'wb');stream_copy_to_stream($src,$o);fclose($src);fclose($o);$saved[]=$rel;}$z->close();
  }
  if(isset($_FILES['source_files']['name'])&&is_array($_FILES['source_files']['name'])){
    foreach($_FILES['source_files']['name'] as $i=>$name){if(($_FILES['source_files']['error'][$i]??1)!==UPLOAD_ERR_OK)continue;$full=(string)($_FILES['source_files']['full_path'][$i]??$name);$rel=x1mig_rel($full);if($rel==='')continue;$dst=X1MIG_STAGE.'/'.$rel;@mkdir(dirname($dst),0775,true);if(move_uploaded_file((string)$_FILES['source_files']['tmp_name'][$i],$dst))$saved[]=$rel;}
  }
  if(!$saved)throw new RuntimeException('Nenhum ficheiro recebido. Verifica também upload_max_filesize/post_max_size do PHP.');
  $m=['created_at'=>date(DATE_ATOM),'files'=>array_values(array_unique($saved))];jwrite(X1MIG_STAGE.'/manifest.json',$m);return$m;
}
function x1mig_files():array{
  if(!is_dir(X1MIG_STAGE))return[];$out=[];$it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator(X1MIG_STAGE,FilesystemIterator::SKIP_DOTS));
  foreach($it as $f){if(!$f->isFile())continue;$rel=substr($f->getPathname(),strlen(X1MIG_STAGE)+1);if($rel!=='manifest.json')$out[$rel]=$f->getPathname();}return$out;
}
function x1mig_find(array $f,string $suffix):?string{$suffix=strtolower(str_replace('\\','/',$suffix));foreach($f as $rel=>$p){$r=strtolower(str_replace('\\','/',$rel));if($r===$suffix||str_ends_with($r,'/'.$suffix))return$p;}return null;}
function x1mig_sql_rows(string $file,string $table):array{
  if(!class_exists('SQLite3'))throw new RuntimeException('php-sqlite3 não está instalado.');
  if(!in_array($table,['vpn','messages','logging','api_key','sports'],true))throw new RuntimeException('Tabela SQLite não suportada.');
  $db=new SQLite3($file,SQLITE3_OPEN_READONLY);$res=$db->query('SELECT * FROM '.$table);$out=[];while($r=$res->fetchArray(SQLITE3_ASSOC))$out[]=$r;$db->close();return$out;
}
function x1mig_report():array{
  $f=x1mig_files();$defs=[
    ['main','Configuração principal','api/main.json','json',true],['connv2','Configuração connv2','api/connv2.json','json',false],
    ['vpn','VPN','api/.db.db','sqlite',false],['messages','Mensagens','api/user_message.db','sqlite',false],['devices','Dispositivos / presença','api/user_logs.db','sqlite',false],['tmdb','TMDB','api/.bet_tmdb.db','sqlite',false],['sports','Sports','api/sports.db','sqlite',false],
    ['intro','Intro','api/intro.mp4','asset',false],['api_logo','Logo APK','api/logo.png','asset',false],['admin_logo','Logo painel','img/logo.png','asset',false]
  ];$items=[];$known=[];
  foreach($defs as [$id,$label,$suf,$kind,$req]){$p=x1mig_find($f,$suf);$status=$p?'ready':($req?'missing':'absent');$detail='';
    if($p){$known[realpath($p)?:$p]=true;if($kind==='json'){$j=jread($p,null);if(!is_array($j)){$status='conflict';$detail='JSON inválido.';}elseif($id==='main'){$n=count((array)($j['app']??[]));$detail=$n.' chaves de primeiro nível em app'.($n===117?' (esperado)':'');if(!isset($j['app'])||!is_array($j['app']))$status='conflict';}else$detail=count($j).' campos encontrados.';}
      elseif($kind==='sqlite'){if(!class_exists('SQLite3')){$status='action';$detail='Ficheiro encontrado; instalar php-sqlite3 para importar.';}else $detail='SQLite pronto para importação.';}
      else $detail=number_format(filesize($p)/1024,1).' KB';}
    $items[]=['id'=>$id,'label'=>$label,'path'=>$p,'kind'=>$kind,'required'=>$req,'status'=>$status,'detail'=>$detail];}
  $unknown=[];foreach($f as $rel=>$p)if(!isset($known[realpath($p)?:$p]))$unknown[]=$rel;
  return['items'=>$items,'unknown'=>$unknown,'count'=>count($f),'sqlite'=>class_exists('SQLite3'),'zip'=>class_exists('ZipArchive')];
}
function x1mig_apply():array{
  $r=x1mig_report();foreach($r['items'] as $it)if($it['required']&&!in_array($it['status'],['ready','action'],true))throw new RuntimeException('Migração bloqueada por '.$it['label'].'.');
  $bk=PANEL_ROOT.'/uploads/pre-migration-'.date('Ymd-His').'.x1backup';@mkdir(dirname($bk),0775,true);file_put_contents($bk,x1_panel_backup_json(),LOCK_EX);
  $f=x1mig_files();$done=[];$skip=[];
  if($p=x1mig_find($f,'api/main.json')){$j=jread($p,[]);$c=config();$c['tag']=$j['tag']??$c['tag'];$c['success']=$j['success']??$c['success'];$c['api_ver']=$j['api_ver']??$c['api_ver'];$c['which']=$j['which']??$c['which'];$c['app']=$j['app'];save_config($c);$done[]='main.json';}
  if($p=x1mig_find($f,'api/connv2.json')){$c=config();$c['connv2']=jread($p,[]);save_config($c);$done[]='connv2.json';}
  $dbs=[['api/.db.db','vpn','vpn'],['api/user_message.db','messages','messages'],['api/user_logs.db','logging','devices']];
  foreach($dbs as [$suf,$table,$dest]){if(!($p=x1mig_find($f,$suf)))continue;if(!class_exists('SQLite3')){$skip[]=$suf;continue;}foreach(x1mig_sql_rows($p,$table) as $row){if($dest==='devices'){$u=(string)($row['uid']??'');if($u==='')continue;$m=['userid'=>$u,'appid'=>$row['appid']??'','version'=>$row['version']??'','device_type'=>$row['device']??'','package_name'=>$row['pkg']??'','app_name'=>$row['app']??'','customerid'=>$row['cid']??'','online'=>$row['status']??'','device_id'=>$row['d']??'','ip'=>$row['IP']??'','first_seen'=>$row['time']??'','last_online'=>$row['last_online']??'','last_seen'=>$row['ping']??''];upsert_row('devices','userid',$u,$m);}elseif($dest==='messages'){upsert_row('messages','userid',(string)($row['userid']??$row['id']),$row);}else{upsert_row('vpn','id',(string)($row['id']??nextid(rows('vpn'))),$row);}}$done[]=$dest;}
  if($p=x1mig_find($f,'api/.bet_tmdb.db')){if(class_exists('SQLite3')){$x=x1mig_sql_rows($p,'api_key')[0]??[];$s=store();$s['tmdb']=['api_key'=>$x['key']??'','language'=>$x['language']??'pt-PT'];save_store($s);$done[]='TMDB';}else$skip[]='TMDB';}
  if($p=x1mig_find($f,'api/sports.db')){if(class_exists('SQLite3')){$x=x1mig_sql_rows($p,'sports')[0]??[];$s=store();$s['sports']=array_replace($s['sports']??[],['provider'=>'tvsportguide','auto_s'=>$x['auto_s']??'','header_n'=>$x['header_n']??'Sports','border_c'=>$x['border_c']??'#222222','background_c'=>$x['background_c']??'#000000','text_c'=>$x['text_c']??'#ffffff','days'=>(int)($x['days']??7)]);save_store($s);$done[]='Sports';}else$skip[]='Sports';}
  foreach([['api/intro.mp4','api/intro.mp4'],['api/logo.png','api/logo.png'],['img/logo.png','assets/logo.png']] as [$src,$dst])if($p=x1mig_find($f,$src)){@mkdir(dirname(PANEL_ROOT.'/'.$dst),0775,true);copy($p,PANEL_ROOT.'/'.$dst);$done[]=$dst;}
  if(($p=x1mig_find($f,'api/logo.png'))&&!x1mig_find($f,'img/logo.png'))copy($p,PANEL_ROOT.'/assets/logo.png');
  if(($p=x1mig_find($f,'img/logo.png'))&&!x1mig_find($f,'api/logo.png'))copy($p,PANEL_ROOT.'/api/logo.png');
  audit_log('migration_apply','Importados: '.implode(', ',$done).($skip?'; pendentes: '.implode(', ',$skip):''));notify('migration','Migração X1 aplicada','Importados: '.implode(', ',$done),$skip?'warning':'success');
  return['done'=>$done,'skip'=>$skip,'backup'=>basename($bk)];
}
$msg=[];$err=[];$applied=null;
if($_SERVER['REQUEST_METHOD']==='POST'){csrf_check();try{$a=(string)($_POST['action']??'analyze');if($a==='analyze'){$m=x1mig_upload();$msg[]='Fonte recebida: '.count($m['files']).' ficheiros. Revê o relatório antes de aplicar.';}elseif($a==='apply'){$applied=x1mig_apply();$msg[]='Migração aplicada com backup automático.';}elseif($a==='clear'){x1mig_clear();$msg[]='Área de migração limpa.';}}catch(Throwable $e){$err[]=$e->getMessage();}}
$report=is_file(X1MIG_STAGE.'/manifest.json')?x1mig_report():null;
top('Assistente de Migração X1');foreach($msg as $m)echo'<p class=ok>'.h($m).'</p>';foreach($err as $m)echo'<p class=err>'.h($m).'</p>';
?>
<div class=card><h2>1. Analisar origem</h2><p>Carrega o ZIP do painel antigo ou seleciona diretamente a pasta/ficheiros. <strong>Nada é alterado nesta etapa.</strong></p>
<form method=post enctype="multipart/form-data"><input type=hidden name=csrf value="<?=csrf_token()?>"><input type=hidden name=action value=analyze><div class=formgrid>
<label class=field><span>ZIP completo</span><input type=file name=source_zip accept=".zip"><small><?=class_exists('ZipArchive')?'ZIP suportado.':'php-zip indisponível; usa pasta/ficheiros.'?></small></label>
<label class=field><span>Pasta / ficheiros</span><input type=file name="source_files[]" multiple webkitdirectory directory><small>Reconhece automaticamente a estrutura do painel anterior.</small></label></div><button class=btn>Analisar migração</button></form></div>
<?php if($report):?><div class=card><h2>2. Relatório antes de aplicar</h2><p><strong><?=$report['count']?></strong> ficheiros recebidos · SQLite: <strong><?=$report['sqlite']?'disponível':'indisponível'?></strong></p><table><thead><tr><th>Módulo</th><th>Estado</th><th>Detalhe</th></tr></thead><tbody>
<?php $labels=['ready'=>'PRONTO','missing'=>'EM FALTA','absent'=>'NÃO ENCONTRADO','conflict'=>'CONFLITO','action'=>'AÇÃO NECESSÁRIA'];foreach($report['items'] as $it):?><tr><td><?=h($it['label'])?></td><td><strong><?=h($labels[$it['status']]??$it['status'])?></strong></td><td><?=h($it['detail']?:($it['required']?'Obrigatório.':'Opcional.'))?></td></tr><?php endforeach?></tbody></table>
<?php if($report['unknown']):?><details><summary><?=count($report['unknown'])?> ficheiros não mapeados</summary><pre><?=h(implode("\n",array_slice($report['unknown'],0,200)))?></pre></details><?php endif?>
<div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:16px"><form method=post onsubmit="return confirm('Aplicar a migração? Será criado um backup X1 antes de alterar os dados.')"><input type=hidden name=csrf value="<?=csrf_token()?>"><input type=hidden name=action value=apply><button class=btn>Aplicar migração</button></form><form method=post><input type=hidden name=csrf value="<?=csrf_token()?>"><input type=hidden name=action value=clear><button class="btn secondary">Limpar análise</button></form></div></div><?php endif?>
<?php if($applied):?><div class=card><h2>Resultado</h2><p class=ok>Importado: <?=h(implode(', ',$applied['done']))?></p><?php if($applied['skip']):?><p class=err>Pendente: <?=h(implode(', ',$applied['skip']))?> — instala php-sqlite3 e volta a aplicar para importar essas bases.</p><?php endif?><p>Backup pré-migração: <code><?=h($applied['backup'])?></code></p></div><?php endif?>
<div class=card><h2>O que reconhece</h2><p><code>main.json</code>, <code>connv2.json</code>, VPN, mensagens, dispositivos, TMDB, Sports, intro e logos. A conta administrativa antiga não é importada.</p></div><?php bottom();
