<?php
declare(strict_types=1);
require_once __DIR__.'/../lib/bootstrap.php';
require_admin();
require_once __DIR__.'/_layout.php';

$cfg=config();
$app=$cfg['app']??[];
$saved=false;

$portalGroups=[
 'Live TV'=>['btn_live','btn_live2','btn_live3','btn_live4','btn_live5'],
 'EPG'=>['btn_epg','btn_epg2','btn_epg3','btn_epg4','btn_epg5'],
 'Filmes / VOD'=>['btn_vod','btn_vod2','btn_vod3','btn_vod4','btn_vod5'],
 'Séries'=>['btn_series','btn_series2','btn_series3','btn_series4','btn_series5'],
 'Catch-up'=>['btn_catchup','btn_catchup2','btn_catchup3','btn_catchup4','btn_catchup5'],
 'Rádio'=>['btn_radio','btn_radio2','btn_radio3','btn_radio4','btn_radio5'],
 'Conta'=>['btn_account','btn_account2','btn_account3','btn_account4','btn_account5'],
 'Favoritos'=>['btn_fav','btn_fav2','btn_fav3','btn_fav4','btn_fav5'],
 'Multi-screen'=>['ms','ms2','ms3','ms4','ms5'],
];

$sections=[
 'Acesso e interface'=>[
  'btn_pr'=>'Controlo parental', 'btn_rec'=>'Gravação', 'btn_vpn'=>'VPN', 'btn_noti'=>'Notificações',
  'btn_update'=>'Atualização na APK', 'btn_signup'=>'Registo / Sign up', 'btn_login_settings'=>'Definições no login',
  'btn_login_account'=>'Conta no login', 'settings_app'=>'Definições da aplicação', 'settings_account'=>'Definições da conta',
  'login_logo'=>'Logo no ecrã de login', 'show_expire'=>'Mostrar data de expiração',
 ],
 'Conteúdo e comportamento'=>[
  'portal_vod'=>'Portal dedicado para VOD', 'portal_series'=>'Portal dedicado para Séries',
  'epg_mode'=>'Modo EPG', 'all_cat'=>'Mostrar todas as categorias', 'show_cat_count'=>'Mostrar contagem de categorias',
  'load_last_channel'=>'Carregar último canal', 'bjob'=>'Background job',
 ],
 'Comunicação com o painel'=>[
  'message_enabled'=>'Mensagens individuais', 'announcement_enabled'=>'Anúncios globais',
  'updateuserinfo_enabled'=>'Atualizar dados do utilizador', 'whatsupcheck_enabled'=>'WhatsUp check',
  'send_udid'=>'Enviar UDID do dispositivo', 'logs'=>'Logs enviados/mostrados pela app',
 ],
];

$nested=[
 'vastconfig.vast_enabled'=>'VAST',
 'admobconfig.admob_enabled'=>'AdMob',
 'prebid.prebid_enabled'=>'Prebid',
 'ort_settings.exo_hw'=>'Aceleração HW — EXO',
 'ort_settings.vlc_hw'=>'Aceleração HW — VLC',
 'ort_settings.video_subtiltes_exo'=>'Legendas — EXO',
 'ort_settings.video_subtiltes_vlc'=>'Legendas — VLC',
];

function feature_yes(mixed $v): bool { return strtolower(trim((string)$v))==='yes'; }
function feature_value(string $key,bool $on,array $current): string {
    $old=(string)($current[$key]??'');
    $upper=in_array($old,['Yes','No'],true) || preg_match('/^btn_(live|epg|vod|series|radio|catchup)/',$key);
    return $on ? ($upper?'Yes':'yes') : ($upper?'No':'no');
}
function nested_get(array $a,string $path,mixed $default=null): mixed {
    foreach(explode('.',$path) as $p){ if(!is_array($a)||!array_key_exists($p,$a))return $default; $a=$a[$p]; }
    return $a;
}
function nested_set(array &$a,string $path,mixed $value): void {
    $parts=explode('.',$path); $ref=&$a;
    foreach($parts as $i=>$p){ if($i===count($parts)-1){$ref[$p]=$value;break;} if(!isset($ref[$p])||!is_array($ref[$p]))$ref[$p]=[]; $ref=&$ref[$p]; }
}

if($_SERVER['REQUEST_METHOD']==='POST'){
    csrf_check();
    foreach($portalGroups as $keys){ foreach($keys as $k)$app[$k]=feature_value($k,isset($_POST['f'][$k]),$app); }
    foreach($sections as $items){ foreach($items as $k=>$label)$app[$k]=feature_value($k,isset($_POST['f'][$k]),$app); }
    foreach($nested as $path=>$label){ nested_set($app,$path,isset($_POST['n'][$path])?'yes':'no'); }

    // O contrato original desta build usa xtreamcodes. O interruptor controla a visibilidade das entradas do painel,
    // sem enviar um valor de provider desconhecido que possa quebrar a APK.
    $panelVisible=isset($_POST['panel_visible']);
    $app['panel']='xtreamcodes';
    if(!$panelVisible){
        foreach(['btn_login_settings','btn_login_account','settings_app','settings_account'] as $k)$app[$k]=feature_value($k,false,$app);
        foreach(['btn_account','btn_account2','btn_account3','btn_account4','btn_account5'] as $k)$app[$k]=feature_value($k,false,$app);
    }

    $cfg['app']=$app; save_config($cfg); $saved=true;
}

$panelVisible=feature_yes($app['btn_login_settings']??'no') || feature_yes($app['btn_login_account']??'no') || feature_yes($app['settings_app']??'no') || feature_yes($app['settings_account']??'no');
top('Ativar / Desativar funções da APK');
if($saved)echo '<p class="ok">Funções guardadas e sincronizadas com <code>api/main.json</code>. A APK recebe estes valores no próximo <code>licV3</code>.</p>';
?>
<form method="post" id="feature-form">
<input type="hidden" name="csrf" value="<?=csrf_token()?>">
<div class="card feature-master">
 <h2>Painel / conta dentro da APK</h2>
 <p class="small">A build original usa tecnicamente <code>panel = xtreamcodes</code>. Este interruptor não inventa outro provider: quando está desligado, oculta Conta/Definições e respetivas entradas de login.</p>
 <label class="toggle"><input type="checkbox" name="panel_visible" id="panel-visible" <?=$panelVisible?'checked':''?>> <strong>Mostrar opções do painel na APK</strong></label>
</div>

<h2 class="sectiontitle">Menus por portal</h2>
<div class="grid">
<?php foreach($portalGroups as $name=>$keys): ?>
<div class="card feature-card"><div class="feature-head"><h2><?=h($name)?></h2><button class="btn secondary mini js-all" type="button">Alternar todos</button></div>
<?php foreach($keys as $i=>$k): ?><label class="toggle"><input type="checkbox" name="f[<?=h($k)?>]" <?=feature_yes($app[$k]??'no')?'checked':''?>> Portal <?=$i+1?></label><?php endforeach; ?>
</div>
<?php endforeach; ?>
</div>

<h2 class="sectiontitle">Funções gerais</h2>
<div class="grid">
<?php foreach($sections as $title=>$items): ?>
<div class="card feature-card"><h2><?=h($title)?></h2>
<?php foreach($items as $k=>$label): ?><label class="toggle"><input type="checkbox" name="f[<?=h($k)?>]" <?=feature_yes($app[$k]??'no')?'checked':''?>> <?=h($label)?><small class="code"><?=h($k)?></small></label><?php endforeach; ?>
</div>
<?php endforeach; ?>
<div class="card feature-card"><h2>Publicidade e players</h2>
<?php foreach($nested as $path=>$label): ?><label class="toggle"><input type="checkbox" name="n[<?=h($path)?>]" <?=feature_yes(nested_get($app,$path,'no'))?'checked':''?>> <?=h($label)?><small class="code"><?=h($path)?></small></label><?php endforeach; ?>
</div>
</div>

<div class="card mt"><h2>Ações rápidas</h2><p class="small">Útil para criar perfis de interface sem ter de clicar dezenas de opções.</p>
<button type="button" class="btn secondary" id="enable-all">Ativar tudo</button>
<button type="button" class="btn secondary" id="disable-all">Desativar tudo</button>
<button type="button" class="btn secondary" id="essential">Só funções essenciais</button>
</div>
<div class="sticky-save"><span>As alterações só entram em vigor depois de guardar.</span><button class="btn" type="submit">Guardar e enviar para a APK</button></div>
</form>
<script>
const form=document.getElementById('feature-form');
const featureBoxes=[...form.querySelectorAll('input[type=checkbox]')];
document.querySelectorAll('.js-all').forEach(btn=>btn.addEventListener('click',()=>{const boxes=[...btn.closest('.feature-card').querySelectorAll('input[type=checkbox]')];const turnOn=boxes.some(x=>!x.checked);boxes.forEach(x=>x.checked=turnOn);}));
document.getElementById('enable-all').onclick=()=>featureBoxes.forEach(x=>x.checked=true);
document.getElementById('disable-all').onclick=()=>featureBoxes.forEach(x=>x.checked=false);
document.getElementById('essential').onclick=()=>{featureBoxes.forEach(x=>x.checked=false);['btn_live','btn_vod','btn_series','btn_epg','btn_account','btn_fav','settings_app','settings_account','login_logo','message_enabled','announcement_enabled','show_cat_count','ort_settings.exo_hw','ort_settings.vlc_hw'].forEach(k=>{const el=form.querySelector(`[name="f[${k}]"]`)||form.querySelector(`[name="n[${k}]"]`);if(el)el.checked=true;});document.getElementById('panel-visible').checked=true;};
</script>
<style>
.feature-head{display:flex;align-items:center;justify-content:space-between;gap:12px}.mini{padding:7px 10px;font-size:12px}.toggle{display:flex!important;align-items:center;gap:9px;min-height:34px}.toggle .code{margin-left:auto;opacity:.45;font-size:10px}.feature-master{border-color:rgba(22,216,255,.28)}
</style>
<?php bottom();
