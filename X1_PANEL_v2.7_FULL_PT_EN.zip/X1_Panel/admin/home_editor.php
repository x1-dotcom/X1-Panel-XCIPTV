<?php
declare(strict_types=1);
require_once __DIR__.'/../lib/bootstrap.php';
require_admin();
require_once __DIR__.'/_layout.php';

$cfg=config();
$app=$cfg['app']??[];
$saved=false;
$themes=['d'=>'Standard','1'=>'Tema 1','2'=>'Tema 2','3'=>'Tema 3'];
$languages=['en'=>'English','ar'=>'العربية','bn'=>'বাংলা','zh'=>'中文','fr'=>'Français','hi'=>'हिन्दी','it'=>'Italiano','ml'=>'മലയാളം','pt'=>'Português','es'=>'Español','ru'=>'Русский','sv'=>'Svenska'];
$modules=[
 'live'=>['label'=>'Live TV','icon'=>'▣','key'=>'btn_live'],
 'epg'=>['label'=>'EPG','icon'=>'▤','key'=>'btn_epg'],
 'vod'=>['label'=>'Filmes','icon'=>'▶','key'=>'btn_vod'],
 'series'=>['label'=>'Séries','icon'=>'▥','key'=>'btn_series'],
 'catchup'=>['label'=>'Catch-up','icon'=>'↶','key'=>'btn_catchup'],
 'radio'=>['label'=>'Rádio','icon'=>'◉','key'=>'btn_radio'],
 'fav'=>['label'=>'Favoritos','icon'=>'★','key'=>'btn_fav'],
 'ms'=>['label'=>'Multi-screen','icon'=>'▦','key'=>'ms'],
 'account'=>['label'=>'Conta','icon'=>'●','key'=>'btn_account'],
];
$global=[
 'btn_vpn'=>['VPN','◆'], 'btn_rec'=>['Gravação','●'], 'btn_pr'=>['Parental','⌾'],
 'btn_noti'=>['Notificações','◌'], 'btn_update'=>['Atualização','↥']
];
function home_key(string $base,int $portal):string{return $portal===1?$base:$base.$portal;}
function home_on(mixed $v):bool{return strtolower(trim((string)$v))==='yes';}
function home_value(string $key,bool $on,array $app):string{
 $old=(string)($app[$key]??'');
 $upper=in_array($old,['Yes','No'],true)||preg_match('/^btn_(live|epg|vod|series|radio|catchup)/',$key);
 return $on?($upper?'Yes':'yes'):($upper?'No':'no');
}

if($_SERVER['REQUEST_METHOD']==='POST'){
 csrf_check();
 $theme=(string)($_POST['theme']??'d'); if(!isset($themes[$theme]))$theme='d';
 $lang=(string)($_POST['app_language']??'pt'); if(!isset($languages[$lang]))$lang='pt';
 $app['theme']=$theme;$app['app_language']=$lang;$app['language']=$lang;
 for($p=1;$p<=5;$p++){
  foreach($modules as $m){$k=home_key($m['key'],$p);$app[$k]=home_value($k,isset($_POST['portal'][$p][$m['key']]),$app);}
 }
 foreach($global as $k=>$meta)$app[$k]=home_value($k,isset($_POST['global'][$k]),$app);
 $cfg['app']=$app;save_config($cfg);$saved=true;
}

$portalNames=[];for($i=1;$i<=5;$i++){$k=$i===1?'portal_name':'portal'.$i.'_name';$portalNames[$i]=trim((string)($app[$k]??''))?:'Portal '.$i;}
top('Editor visual da Home X1');
if($saved)echo '<p class="ok">Home guardada. As opções suportadas foram sincronizadas com <code>api/main.json</code> e entram no próximo <code>licV3</code>. A ordem dos cartões abaixo é apenas preview: esta build não expõe uma chave de ordenação.</p>';
?>
<form method="post" id="home-editor-form">
<input type="hidden" name="csrf" value="<?=csrf_token()?>">
<div class="home-editor-shell">
 <section class="home-preview-panel">
  <div class="card home-preview-card">
   <div class="card-head"><div><h2>Pré-visualização da Home</h2><p class="small">Representação administrativa baseada nas flags reais desta APK.</p></div><span class="badge">Preview</span></div>
   <div class="x1-tv" id="x1-preview">
    <div class="x1-tv-top"><img src="../assets/logo.png" alt="X1"><div><strong id="preview-portal-name"><?=h($portalNames[1])?></strong><small id="preview-lang"><?=h(strtoupper((string)($app['app_language']??'pt')))?></small></div></div>
    <div class="x1-home-grid" id="preview-grid"></div>
    <div class="x1-tv-foot"><span>Tema <b id="preview-theme"><?=h((string)($app['theme']??'d'))?></b></span><span>X1</span></div>
   </div>
   <p class="warn small"><strong>Compatibilidade:</strong> ligar/desligar módulos, tema e idioma são enviados à APK. A disposição dos cartões neste preview não altera a ordem nativa porque não existe uma chave de ordenação no contrato desta build.</p>
  </div>
 </section>
 <section class="home-controls-panel">
  <div class="card">
   <h2>Aparência</h2>
   <div class="formgrid">
    <label class="field"><span>Tema</span><select name="theme" id="theme-select"><?php foreach($themes as $k=>$v):?><option value="<?=h($k)?>" <?=((string)($app['theme']??'d')===$k)?'selected':''?>><?=h($v)?></option><?php endforeach?></select></label>
    <label class="field"><span>Idioma</span><select name="app_language" id="lang-select"><?php foreach($languages as $k=>$v):?><option value="<?=h($k)?>" <?=((string)($app['app_language']??'pt')===$k)?'selected':''?>><?=h($v)?> (<?=h($k)?>)</option><?php endforeach?></select></label>
   </div>
  </div>
  <div class="card mt">
   <div class="card-head"><div><h2>Portal</h2><p class="small">Escolhe o portal cuja Home queres editar.</p></div></div>
   <div class="portal-tabs" id="portal-tabs"><?php for($p=1;$p<=5;$p++):?><button type="button" class="portal-tab <?=$p===1?'active':''?>" data-portal="<?=$p?>" data-name="<?=h($portalNames[$p])?>">P<?=$p?><small><?=h($portalNames[$p])?></small></button><?php endfor?></div>
  </div>
  <?php for($p=1;$p<=5;$p++):?>
  <div class="card mt portal-config <?=$p===1?'':'hidden'?>" data-portal-config="<?=$p?>">
   <h2><?=h($portalNames[$p])?></h2>
   <div class="visual-feature-list">
   <?php foreach($modules as $m):$k=home_key($m['key'],$p);?>
    <label class="visual-switch"><span class="v-icon"><?=h($m['icon'])?></span><span><strong><?=h($m['label'])?></strong><small><code><?=h($k)?></code></small></span><input class="home-flag" data-portal="<?=$p?>" data-label="<?=h($m['label'])?>" data-icon="<?=h($m['icon'])?>" type="checkbox" name="portal[<?=$p?>][<?=h($m['key'])?>]" <?=home_on($app[$k]??'no')?'checked':''?>><i></i></label>
   <?php endforeach?>
   </div>
  </div>
  <?php endfor?>
  <div class="card mt">
   <h2>Funções globais</h2><p class="small">Estas flags não são específicas de um portal.</p>
   <div class="visual-feature-list"><?php foreach($global as $k=>$meta):?><label class="visual-switch"><span class="v-icon"><?=h($meta[1])?></span><span><strong><?=h($meta[0])?></strong><small><code><?=h($k)?></code></small></span><input class="global-home-flag" data-label="<?=h($meta[0])?>" data-icon="<?=h($meta[1])?>" type="checkbox" name="global[<?=h($k)?>]" <?=home_on($app[$k]??'no')?'checked':''?>><i></i></label><?php endforeach?></div>
  </div>
 </section>
</div>
<div class="sticky-save"><span><strong id="enabled-count">0</strong> módulos visíveis no preview atual.</span><button class="btn" type="submit">Guardar Home X1</button></div>
</form>
<script>
(()=>{
 let portal=1;
 const grid=document.getElementById('preview-grid'), count=document.getElementById('enabled-count');
 const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 function draw(){
  const local=[...document.querySelectorAll('.home-flag[data-portal="'+portal+'"]:checked')];
  const global=[...document.querySelectorAll('.global-home-flag:checked')];
  const all=[...local,...global];
  grid.innerHTML=all.length?all.map(x=>'<div class="x1-home-tile"><span>'+esc(x.dataset.icon)+'</span><b>'+esc(x.dataset.label)+'</b></div>').join(''):'<div class="x1-empty">Nenhum módulo ativo neste portal.</div>';
  count.textContent=all.length;
  document.getElementById('preview-theme').textContent=document.getElementById('theme-select').value;
  document.getElementById('preview-lang').textContent=document.getElementById('lang-select').value.toUpperCase();
 }
 document.querySelectorAll('.portal-tab').forEach(b=>b.addEventListener('click',()=>{
  portal=Number(b.dataset.portal);document.querySelectorAll('.portal-tab').forEach(x=>x.classList.toggle('active',x===b));
  document.querySelectorAll('.portal-config').forEach(x=>x.classList.toggle('hidden',Number(x.dataset.portalConfig)!==portal));
  document.getElementById('preview-portal-name').textContent=b.dataset.name;draw();
 }));
 document.querySelectorAll('.home-flag,.global-home-flag,#theme-select,#lang-select').forEach(x=>x.addEventListener('change',draw));draw();
})();
</script>
<?php bottom();
