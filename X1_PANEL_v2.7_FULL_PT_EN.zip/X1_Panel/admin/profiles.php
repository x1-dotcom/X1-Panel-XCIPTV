<?php
declare(strict_types=1);
require_once __DIR__.'/../lib/bootstrap.php';
require_admin();
require_once __DIR__.'/_layout.php';

function pv_nested_get(array $a,string $path,mixed $default=null):mixed{foreach(explode('.',$path) as $p){if(!is_array($a)||!array_key_exists($p,$a))return $default;$a=$a[$p];}return $a;}
function pv_nested_set(array &$a,string $path,mixed $value):void{$parts=explode('.',$path);$r=&$a;foreach($parts as $i=>$p){if($i===count($parts)-1){$r[$p]=$value;return;}if(!isset($r[$p])||!is_array($r[$p]))$r[$p]=[];$r=&$r[$p];}}
function pv_nested_unset(array &$a,string $path):void{$parts=explode('.',$path);$last=array_pop($parts);$r=&$a;foreach($parts as $p){if(!isset($r[$p])||!is_array($r[$p]))return;$r=&$r[$p];}unset($r[$last]);}
function pv_bool_value(string $key,bool $on,array $global):string{$old=(string)($global[$key]??'');$upper=in_array($old,['Yes','No'],true)||preg_match('/^btn_(live|epg|vod|series|radio|catchup)/',$key);return $on?($upper?'Yes':'yes'):($upper?'No':'no');}
function pv_feature_state(array $ov,string $key):string{if(!array_key_exists($key,$ov))return'inherit';return strtolower((string)$ov[$key])==='yes'?'on':'off';}
function pv_nested_state(array $ov,string $path):string{$v=pv_nested_get($ov,$path,null);if($v===null)return'inherit';return strtolower((string)$v)==='yes'?'on':'off';}

$cfg=config();$global=$cfg['app']??[];
$themes=['inherit'=>'Herdar configuração global','d'=>'Standard','1'=>'Tema 1','2'=>'Tema 2','3'=>'Tema 3'];
$languages=['inherit'=>'Herdar','en'=>'English','ar'=>'العربية','bn'=>'বাংলা','zh'=>'中文','fr'=>'Français','hi'=>'हिन्दी','it'=>'Italiano','ml'=>'മലയാളം','pt'=>'Português','es'=>'Español','ru'=>'Русский','sv'=>'Svenska'];
$players=['inherit'=>'Herdar','EXO'=>'EXO Player','VLC'=>'VLC Player','MX'=>'MX Player','SYSTEM'=>'System / externo'];
$portalGroups=[
 'Live TV'=>['btn_live','btn_live2','btn_live3','btn_live4','btn_live5'],
 'EPG'=>['btn_epg','btn_epg2','btn_epg3','btn_epg4','btn_epg5'],
 'Filmes / VOD'=>['btn_vod','btn_vod2','btn_vod3','btn_vod4','btn_vod5'],
 'Séries'=>['btn_series','btn_series2','btn_series3','btn_series4','btn_series5'],
 'Catch-up'=>['btn_catchup','btn_catchup2','btn_catchup3','btn_catchup4','btn_catchup5'],
 'Rádio'=>['btn_radio','btn_radio2','btn_radio3','btn_radio4','btn_radio5'],
 'Conta'=>['btn_account','btn_account2','btn_account3','btn_account4','btn_account5'],
 'Favoritos'=>['btn_fav','btn_fav2','btn_fav3','btn_fav4','btn_fav5'],
 'Multi-screen'=>['ms','ms2','ms3','ms4','ms5'],
];
$generalFeatures=[
 'btn_pr'=>'Controlo parental','btn_rec'=>'Gravação','btn_vpn'=>'VPN','btn_noti'=>'Notificações','btn_update'=>'Atualização na APK','btn_signup'=>'Registo / Sign up',
 'btn_login_settings'=>'Definições no login','btn_login_account'=>'Conta no login','settings_app'=>'Definições da aplicação','settings_account'=>'Definições da conta',
 'login_logo'=>'Logo no login','show_expire'=>'Mostrar expiração','portal_vod'=>'Portal dedicado VOD','portal_series'=>'Portal dedicado Séries','epg_mode'=>'Modo EPG',
 'all_cat'=>'Todas as categorias','show_cat_count'=>'Contagem de categorias','load_last_channel'=>'Carregar último canal','message_enabled'=>'Mensagens individuais',
 'announcement_enabled'=>'Anúncios globais','updateuserinfo_enabled'=>'Atualizar dados do utilizador','whatsupcheck_enabled'=>'WhatsUp check','send_udid'=>'Enviar UDID','logs'=>'Logs da APK'
];
$nestedFeatures=[
 'vastconfig.vast_enabled'=>'VAST','admobconfig.admob_enabled'=>'AdMob','prebid.prebid_enabled'=>'Prebid',
 'ort_settings.exo_hw'=>'Hardware EXO','ort_settings.vlc_hw'=>'Hardware VLC','ort_settings.video_subtiltes_exo'=>'Legendas EXO','ort_settings.video_subtiltes_vlc'=>'Legendas VLC'
];
$managedSimple=['theme','app_language','language','player','player_tv','player_vod','player_series','player_catchup','stream_type','agent'];
foreach($portalGroups as $ks)foreach($ks as $k)$managedSimple[]=$k;foreach(array_keys($generalFeatures) as $k)$managedSimple[]=$k;
for($i=1;$i<=5;$i++){$managedSimple[]=$i===1?'portal':'portal'.$i;$managedSimple[]=$i===1?'portal_name':'portal'.$i.'_name';}

$msg='';$err='';$edit=null;if(isset($_GET['edit']))$edit=find_row('profiles','id',(string)$_GET['edit']);
if($_SERVER['REQUEST_METHOD']==='POST'){
 csrf_check();$action=(string)($_POST['action']??'save');$id=(string)($_POST['id']??'');
 if($action==='delete'&&$id!==''){
  delete_row('profiles','id',$id);audit_log('profile_delete','ID '.$id);$msg='Perfil removido. Licenças que o usavam passam a herdar a configuração global.';
 }elseif($action==='preset'){
  $key=(string)($_POST['preset']??'');$presets=x1_profile_presets();
  if(isset($presets[$key])){$pr=$presets[$key];$ov=$pr['overrides'];foreach($ov as $k=>$v){if(is_string($v)&&in_array(strtolower($v),['yes','no'],true))$ov[$k]=pv_bool_value($k,strtolower($v)==='yes',$global);} $rid=nextid(rows('profiles'));upsert_row('profiles','id',(string)$rid,['id'=>$rid,'name'=>$pr['name'],'description'=>$pr['description'],'app_overrides'=>$ov,'created_at'=>now(),'updated_at'=>now()]);audit_log('profile_preset_create',$pr['name']);$msg='Preset criado como perfil visual editável.';}
 }elseif($action==='clone'&&$id!==''){
  $src=find_row('profiles','id',$id);if($src){$rid=nextid(rows('profiles'));$src['id']=$rid;$src['name']=($src['name']??'Perfil').' — cópia';$src['created_at']=now();$src['updated_at']=now();upsert_row('profiles','id',(string)$rid,$src);audit_log('profile_clone',(string)$src['name']);$msg='Perfil clonado.';}
 }else{
  $name=trim((string)($_POST['name']??''));if($name==='')$err='Indica um nome para o perfil.';
  $old=$id!==''?find_row('profiles','id',$id):null;$ov=is_array($old['app_overrides']??null)?$old['app_overrides']:[];
  foreach($managedSimple as $k)unset($ov[$k]);foreach(array_keys($nestedFeatures) as $path)pv_nested_unset($ov,$path);
  foreach(['theme','app_language','language','player','player_tv','player_vod','player_series','player_catchup','stream_type'] as $k){$v=(string)($_POST[$k]??'inherit');if($v!=='inherit'&&$v!=='')$ov[$k]=$v;}
  $agentMode=(string)($_POST['agent_mode']??'inherit');if($agentMode==='custom')$ov['agent']=trim((string)($_POST['agent']??''));
  for($i=1;$i<=5;$i++)if(isset($_POST['portal_override'][$i])){$pk=$i===1?'portal':'portal'.$i;$nk=$i===1?'portal_name':'portal'.$i.'_name';$ov[$pk]=trim((string)($_POST['portal'][$i]??''));$ov[$nk]=trim((string)($_POST['portal_name'][$i]??''));}
  foreach($portalGroups as $ks)foreach($ks as $k){$st=(string)($_POST['feature'][$k]??'inherit');if($st==='on'||$st==='off')$ov[$k]=pv_bool_value($k,$st==='on',$global);}
  foreach($generalFeatures as $k=>$label){$st=(string)($_POST['feature'][$k]??'inherit');if($st==='on'||$st==='off')$ov[$k]=pv_bool_value($k,$st==='on',$global);}
  foreach($nestedFeatures as $path=>$label){$st=(string)($_POST['nested'][$path]??'inherit');if($st==='on'||$st==='off')pv_nested_set($ov,$path,$st==='on'?'yes':'no');}
  $extraRaw=trim((string)($_POST['extra_json']??''));if($extraRaw!==''){$extra=json_decode($extraRaw,true);if(!is_array($extra))$err='JSON avançado inválido.';else $ov=array_replace_recursive($ov,$extra);}
  if(!$err){$rid=$id!==''?(int)$id:nextid(rows('profiles'));upsert_row('profiles','id',(string)$rid,['id'=>$rid,'name'=>$name,'description'=>trim((string)($_POST['description']??'')),'app_overrides'=>$ov,'created_at'=>$old['created_at']??now(),'updated_at'=>now()]);audit_log('profile_save',$name.' · '.count($ov).' overrides');$msg='Perfil guardado. As licenças atribuídas recebem este overlay no próximo pedido.';$edit=find_row('profiles','id',(string)$rid);}
 }
}
$v=$edit??[];$ov=is_array($v['app_overrides']??null)?$v['app_overrides']:[];
// Apenas extras não geridos visualmente aparecem no editor técnico.
$extras=$ov;foreach($managedSimple as $k)unset($extras[$k]);foreach(array_keys($nestedFeatures) as $path)pv_nested_unset($extras,$path);$extras=array_filter($extras,fn($x)=>$x!==[]);
$extraJson=$extras?json_encode($extras,JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE):'';
$overrideCount=0;array_walk_recursive($ov,function()use(&$overrideCount){$overrideCount++;});

top('Editor visual de Perfis X1');if($msg)echo'<p class=ok>'.h($msg).'</p>';if($err)echo'<p class=err>'.h($err).'</p>';
?>
<div class="card profile-intro"><div><h2>Perfil = overlay, não cópia</h2><p>Escolhe apenas o que deve ser diferente da configuração global. <strong>Herdar</strong> significa que futuras alterações globais continuam a chegar a esse dispositivo.</p></div><div class="profile-stat"><strong id="override-count"><?=$overrideCount?></strong><span>valores substituídos</span></div></div>

<div class="card mt"><h2>Presets de arranque</h2><p class="small">Criam um perfil editável. Depois podes ajustar visualmente qualquer opção.</p><div class="preset-row"><?php foreach(x1_profile_presets() as $k=>$pr):?><form method="post"><input type="hidden" name="csrf" value="<?=csrf_token()?>"><input type="hidden" name="action" value="preset"><input type="hidden" name="preset" value="<?=h($k)?>"><button class="preset-btn"><strong><?=h($pr['name'])?></strong><small><?=h($pr['description'])?></small></button></form><?php endforeach?></div></div>

<form method="post" id="profile-editor">
<input type="hidden" name="csrf" value="<?=csrf_token()?>"><input type="hidden" name="id" value="<?=h($v['id']??'')?>">
<div class="profile-layout mt"><div class="profile-main">
<div class="card"><h2>Identidade do perfil</h2><div class="formgrid"><label class="field"><span>Nome</span><input name="name" required value="<?=h($v['name']??'')?>" placeholder="Ex.: Portugal Premium"></label><label class="field"><span>Descrição</span><input name="description" value="<?=h($v['description']??'')?>" placeholder="Quem deve receber este perfil"></label></div></div>

<div class="card mt"><h2>Tema e idioma</h2><div class="theme-picker compact-themes"><?php foreach($themes as $code=>$label):$sel=($code==='inherit'?!array_key_exists('theme',$ov):(string)($ov['theme']??'')===$code);?><label class="theme-option"><input type="radio" name="theme" value="<?=h($code)?>" <?=$sel?'checked':''?>><?php if($code==='inherit'):?><span class="theme-frame inherit-frame"><span class="inherit-icon">↳</span><strong>Herdar tema</strong><small>Global: <?=h($global['theme']??'d')?></small></span><?php else:?><span class="theme-frame"><img src="../assets/themes/<?=h($code)?>.jpg" alt="<?=h($label)?>"><strong><?=h($label)?></strong><small>Código <?=h($code)?></small></span><?php endif?></label><?php endforeach?></div>
<div class="formgrid mt"><label class="field"><span>Idioma principal</span><select name="app_language"><?php foreach($languages as $code=>$label):$current=array_key_exists('app_language',$ov)?(string)$ov['app_language']:'inherit';?><option value="<?=h($code)?>" <?=$current===$code?'selected':''?>><?=h($label)?><?=$code==='inherit'?' · global '.h($global['app_language']??'pt'):''?></option><?php endforeach?></select></label><label class="field"><span>Idioma compatibilidade</span><select name="language"><?php foreach($languages as $code=>$label):$current=array_key_exists('language',$ov)?(string)$ov['language']:'inherit';?><option value="<?=h($code)?>" <?=$current===$code?'selected':''?>><?=h($label)?><?=$code==='inherit'?' · global '.h($global['language']??'pt'):''?></option><?php endforeach?></select></label></div></div>

<div class="card mt"><div class="card-head"><div><h2>Portais por perfil</h2><p class="small">Só ativa o override nos portais que devem ser diferentes do global.</p></div></div><div class="portal-editor-grid"><?php for($i=1;$i<=5;$i++):$pk=$i===1?'portal':'portal'.$i;$nk=$i===1?'portal_name':'portal'.$i.'_name';$has=array_key_exists($pk,$ov)||array_key_exists($nk,$ov);?><div class="portal-edit"><label class="toggle strong-toggle"><input class="portal-override" type="checkbox" name="portal_override[<?=$i?>]" <?=$has?'checked':''?>> Personalizar Portal <?=$i?></label><div class="portal-fields <?=$has?'':'muted-block'?>"><label class="field"><span>Nome</span><input name="portal_name[<?=$i?>]" value="<?=h($has?($ov[$nk]??''):($global[$nk]??''))?>"></label><label class="field"><span>URL</span><input name="portal[<?=$i?>]" value="<?=h($has?($ov[$pk]??''):($global[$pk]??''))?>" placeholder="https://..."></label><p class="small inherit-note">Global: <?=h($global[$nk]??('Portal '.$i))?> · <?=h($global[$pk]??'')?></p></div></div><?php endfor?></div></div>

<div class="card mt"><h2>Players e reprodução</h2><div class="formgrid"><?php foreach(['player'=>'Player padrão','player_tv'=>'Live TV','player_vod'=>'Filmes','player_series'=>'Séries','player_catchup'=>'Catch-up'] as $k=>$label):$cur=array_key_exists($k,$ov)?(string)$ov[$k]:'inherit';?><label class="field"><span><?=h($label)?></span><select name="<?=h($k)?>"><?php foreach($players as $code=>$pname):?><option value="<?=h($code)?>" <?=$cur===$code?'selected':''?>><?=h($pname)?><?=$code==='inherit'?' · global '.h($global[$k]??'EXO'):''?></option><?php endforeach?></select></label><?php endforeach?><label class="field"><span>Stream type</span><select name="stream_type"><?php $cur=array_key_exists('stream_type',$ov)?(string)$ov['stream_type']:'inherit';foreach(['inherit'=>'Herdar · global '.($global['stream_type']??'ts'),'ts'=>'TS','m3u8'=>'HLS / m3u8'] as $code=>$label):?><option value="<?=h($code)?>" <?=$cur===$code?'selected':''?>><?=h($label)?></option><?php endforeach?></select></label><label class="field"><span>User-Agent</span><select name="agent_mode" id="agent-mode"><option value="inherit" <?=array_key_exists('agent',$ov)?'':'selected'?>>Herdar · <?=h($global['agent']??'')?></option><option value="custom" <?=array_key_exists('agent',$ov)?'selected':''?>>Personalizado</option></select><input id="agent-input" name="agent" value="<?=h($ov['agent']??$global['agent']??'')?>" placeholder="User-Agent"></label></div></div>

<h2 class="sectiontitle">Menus por portal</h2><div class="grid feature-profile-grid"><?php foreach($portalGroups as $label=>$keys):?><div class="card"><div class="feature-head"><h2><?=h($label)?></h2><button type="button" class="btn secondary mini group-inherit">Herdar grupo</button></div><?php foreach($keys as $i=>$k):$st=pv_feature_state($ov,$k);?><label class="tri-row"><span>Portal <?=$i+1?></span><select name="feature[<?=h($k)?>]" data-tri><option value="inherit" <?=$st==='inherit'?'selected':''?>>Herdar</option><option value="on" <?=$st==='on'?'selected':''?>>Ativar</option><option value="off" <?=$st==='off'?'selected':''?>>Desativar</option></select></label><?php endforeach?></div><?php endforeach?></div>

<h2 class="sectiontitle">Funções gerais</h2><div class="grid feature-profile-grid"><?php foreach(array_chunk($generalFeatures,(int)ceil(count($generalFeatures)/3),true) as $chunk):?><div class="card"><?php foreach($chunk as $k=>$label):$st=pv_feature_state($ov,$k);?><label class="tri-row"><span><?=h($label)?><small><?=h($k)?></small></span><select name="feature[<?=h($k)?>]" data-tri><option value="inherit" <?=$st==='inherit'?'selected':''?>>Herdar</option><option value="on" <?=$st==='on'?'selected':''?>>Ativar</option><option value="off" <?=$st==='off'?'selected':''?>>Desativar</option></select></label><?php endforeach?></div><?php endforeach?><div class="card"><?php foreach($nestedFeatures as $path=>$label):$st=pv_nested_state($ov,$path);?><label class="tri-row"><span><?=h($label)?><small><?=h($path)?></small></span><select name="nested[<?=h($path)?>]" data-tri><option value="inherit" <?=$st==='inherit'?'selected':''?>>Herdar</option><option value="on" <?=$st==='on'?'selected':''?>>Ativar</option><option value="off" <?=$st==='off'?'selected':''?>>Desativar</option></select></label><?php endforeach?></div></div>

<details class="card mt advanced"><summary>Avançado · overrides adicionais</summary><p class="small">Apenas para campos não cobertos pelo editor visual. O conteúdo é fundido com o perfil.</p><label class="field"><span>JSON adicional</span><textarea name="extra_json" spellcheck="false" placeholder='{"activation_url":"..."}'><?=h($extraJson)?></textarea></label></details>
<div class="sticky-save"><span><strong id="save-summary">Perfil em modo overlay.</strong> Só os campos selecionados substituem o global.</span><button class="btn" type="submit">Guardar perfil</button></div>
</div>

<aside class="profile-preview card"><span class="preview-kicker">PREVIEW DO PERFIL</span><div class="phone"><div class="phone-top"><img src="../assets/logo.png"><strong id="preview-name"><?=h($v['name']??'Novo perfil')?></strong><small id="preview-lang"><?=h($ov['app_language']??$global['app_language']??'pt')?></small></div><div class="screen-theme"><img id="preview-theme" src="../assets/themes/<?=h(($ov['theme']??$global['theme']??'d'))?>.jpg"><span id="preview-theme-label">Tema <?=h($ov['theme']??$global['theme']??'d')?></span></div><div class="preview-portals" id="preview-portals"></div><div class="preview-features" id="preview-features"></div></div><p class="small">Preview administrativo. Confirma a configuração que o servidor vai compor; a renderização final continua a depender da APK.</p></aside>
</div></form>

<div class="card mt"><h2>Perfis existentes</h2><table><tr><th>ID</th><th>Perfil</th><th>Descrição</th><th>Overrides</th><th>Licenças</th><th>Ações</th></tr><?php foreach(rows('profiles') as $x):$count=count(array_filter(rows('licenses'),fn($l)=>(string)($l['profile_id']??'')===(string)$x['id']));$xo=is_array($x['app_overrides']??null)?$x['app_overrides']:[];$cnt=0;array_walk_recursive($xo,function()use(&$cnt){$cnt++;});?><tr><td><?=h($x['id'])?></td><td><strong><?=h($x['name'])?></strong></td><td><?=h($x['description']??'')?></td><td><span class="badge"><?=$cnt?> valores</span><br><code><?=h(implode(', ',array_slice(array_keys($xo),0,7)))?><?=$cnt>7?'…':''?></code></td><td><?=h($count)?></td><td class="actions"><a class="btn" href="?edit=<?=h($x['id'])?>">Editar visualmente</a><form method="post"><input type="hidden" name="csrf" value="<?=csrf_token()?>"><input type="hidden" name="action" value="clone"><input type="hidden" name="id" value="<?=h($x['id'])?>"><button class="btn secondary">Clonar</button></form><form method="post" onsubmit="return confirm('Apagar este perfil?')"><input type="hidden" name="csrf" value="<?=csrf_token()?>"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?=h($x['id'])?>"><button class="btn danger">Apagar</button></form></td></tr><?php endforeach?></table></div>

<script>
const editor=document.getElementById('profile-editor');
const globalTheme=<?=json_encode((string)($global['theme']??'d'))?>;
const globalLang=<?=json_encode((string)($global['app_language']??'pt'))?>;
const portalGlobals=<?=json_encode(array_map(fn($i)=>['name'=>$global[$i===1?'portal_name':'portal'.$i.'_name']??('Portal '.$i),'url'=>$global[$i===1?'portal':'portal'.$i]??''],range(1,5)),JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE)?>;
function triText(v){return v==='on'?'ON':v==='off'?'OFF':'↳';}
function refreshPreview(){
 const name=editor.querySelector('[name=name]').value||'Novo perfil';document.getElementById('preview-name').textContent=name;
 const theme=editor.querySelector('[name=theme]:checked')?.value||'inherit';const realTheme=theme==='inherit'?globalTheme:theme;document.getElementById('preview-theme').src='../assets/themes/'+realTheme+'.jpg';document.getElementById('preview-theme-label').textContent=theme==='inherit'?'Tema global · '+realTheme:'Tema override · '+realTheme;
 const lang=editor.querySelector('[name=app_language]').value;document.getElementById('preview-lang').textContent=lang==='inherit'?globalLang:lang;
 const pp=document.getElementById('preview-portals');pp.innerHTML='';for(let i=1;i<=5;i++){const cb=editor.querySelector(`[name="portal_override[${i}]"]`);const nm=cb.checked?editor.querySelector(`[name="portal_name[${i}]"]`).value:portalGlobals[i-1].name;if((cb.checked?editor.querySelector(`[name="portal[${i}]"]`).value:portalGlobals[i-1].url)){const e=document.createElement('span');e.textContent=(cb.checked?'★ ':'')+(nm||'Portal '+i);pp.appendChild(e);}}
 const active=[...editor.querySelectorAll('[data-tri]')].filter(x=>x.value!=='inherit');const pf=document.getElementById('preview-features');pf.innerHTML='';active.slice(0,9).forEach(x=>{const e=document.createElement('span');e.className=x.value;e.textContent=triText(x.value)+' '+(x.closest('.tri-row')?.querySelector('span')?.childNodes[0]?.textContent.trim()||x.name);pf.appendChild(e);});if(active.length>9){const e=document.createElement('span');e.textContent='+'+(active.length-9);pf.appendChild(e);}document.getElementById('override-count').textContent=active.length+[...editor.querySelectorAll('.portal-override:checked')].length+[...editor.querySelectorAll('select')].filter(x=>!x.hasAttribute('data-tri')&&x.value!=='inherit'&&x.name!=='agent_mode').length+(theme!=='inherit'?1:0);
 document.getElementById('save-summary').textContent=active.length+' features com override · '+[...editor.querySelectorAll('.portal-override:checked')].length+' portais personalizados';
}
editor.addEventListener('input',refreshPreview);editor.addEventListener('change',refreshPreview);
document.querySelectorAll('.portal-override').forEach(cb=>cb.addEventListener('change',()=>{cb.closest('.portal-edit').querySelector('.portal-fields').classList.toggle('muted-block',!cb.checked);}));
document.querySelectorAll('.group-inherit').forEach(b=>b.onclick=()=>{b.closest('.card').querySelectorAll('[data-tri]').forEach(x=>x.value='inherit');refreshPreview();});
document.getElementById('agent-mode').addEventListener('change',e=>document.getElementById('agent-input').disabled=e.target.value==='inherit');document.getElementById('agent-input').disabled=document.getElementById('agent-mode').value==='inherit';refreshPreview();
</script>
<style>
.profile-intro{display:flex;justify-content:space-between;gap:18px;align-items:center}.profile-intro h2{margin-top:0}.profile-stat{min-width:150px;text-align:center;padding:14px;border:1px solid rgba(34,239,255,.2);border-radius:12px;background:#06111d}.profile-stat strong{display:block;font-size:32px;color:var(--cyan)}.profile-stat span{font-size:11px;color:var(--muted)}
.preset-row{display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:10px}.preset-btn{width:100%;height:100%;text-align:left;padding:14px;background:#071827;color:#fff;border:1px solid rgba(34,239,255,.18);border-radius:11px;cursor:pointer}.preset-btn:hover{border-color:var(--cyan)}.preset-btn strong,.preset-btn small{display:block}.preset-btn small{margin-top:6px;color:var(--muted)}
.profile-layout{display:grid;grid-template-columns:minmax(0,1fr) 320px;gap:14px;align-items:start}.profile-preview{position:sticky;top:18px}.preview-kicker{font-size:10px;letter-spacing:.18em;color:var(--cyan)}.phone{margin-top:12px;border:1px solid rgba(34,239,255,.25);border-radius:24px;padding:11px;background:#02070c;box-shadow:0 20px 50px rgba(0,0,0,.35)}.phone-top{display:grid;grid-template-columns:42px 1fr auto;align-items:center;gap:9px;padding:8px}.phone-top img{width:42px;height:34px;object-fit:contain}.phone-top small{color:var(--cyan)}.screen-theme{position:relative;overflow:hidden;border-radius:14px;border:1px solid rgba(255,255,255,.08)}.screen-theme img{display:block;width:100%;aspect-ratio:16/9;object-fit:cover}.screen-theme span{position:absolute;left:8px;bottom:8px;padding:4px 7px;border-radius:999px;background:rgba(0,0,0,.75);font-size:10px}.preview-portals,.preview-features{display:flex;gap:5px;flex-wrap:wrap;padding:9px 4px 0}.preview-portals span,.preview-features span{padding:4px 6px;border-radius:7px;background:#0b2434;font-size:9px;color:#bcecf4}.preview-features span.on{background:#0e4938;color:#92ffd0}.preview-features span.off{background:#512331;color:#ffb1c0}
.compact-themes{grid-template-columns:repeat(auto-fit,minmax(150px,1fr))}.inherit-frame{min-height:140px;align-content:center;text-align:center}.inherit-icon{font-size:42px;color:var(--cyan)}.portal-editor-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:10px}.portal-edit{padding:12px;border:1px solid rgba(34,239,255,.12);border-radius:11px;background:#06111d}.strong-toggle{font-weight:700}.portal-fields{display:grid;gap:8px;transition:.18s}.muted-block{opacity:.42;filter:saturate(.5)}.inherit-note{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.feature-head{display:flex;align-items:center;justify-content:space-between;gap:8px}.mini{padding:6px 8px;font-size:10px}.tri-row{display:grid;grid-template-columns:minmax(0,1fr) 105px;gap:8px;align-items:center;padding:7px 0;border-bottom:1px solid rgba(34,239,255,.07)}.tri-row:last-child{border-bottom:0}.tri-row span{display:grid}.tri-row small{font-size:9px;color:var(--muted)}.tri-row select{padding:7px;background:#06111d;color:#fff;border:1px solid #17445b;border-radius:7px}.advanced summary{cursor:pointer;font-weight:750;color:#aeeef6}.advanced textarea{min-height:180px}
@media(max-width:1100px){.profile-layout{grid-template-columns:1fr}.profile-preview{position:static}.phone{max-width:420px}}@media(max-width:760px){.profile-intro{align-items:stretch;flex-direction:column}.tri-row{grid-template-columns:1fr}.compact-themes{grid-template-columns:1fr 1fr}}
</style>
<?php bottom();
