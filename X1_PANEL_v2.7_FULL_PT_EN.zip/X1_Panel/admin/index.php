<?php
declare(strict_types=1);
require_once __DIR__.'/../lib/bootstrap.php';require_admin();require_once __DIR__.'/_layout.php';
$c=config();$app=$c['app']??[];$dev=rows('devices');$logs=rows('logs');$licenses=rows('licenses');$now=time();$cut24=$now-86400;
$recentLogs=array_values(array_filter($logs,fn($x)=>strtotime((string)($x['created_at']??'1970-01-01'))>=$cut24));
$errors=array_values(array_filter($recentLogs,fn($x)=>(int)($x['http_status']??0)>=400||in_array(strtoupper((string)($x['success']??'')),['0','FALSE','FAIL','ERROR'],true)));
$dur=array_map(fn($x)=>(int)($x['duration_ms']??0),$recentLogs);sort($dur);$p95=$dur?($dur[(int)floor((count($dur)-1)*.95)]??0):0;
$online=count(array_filter($dev,function($x)use($now){$seen=strtotime((string)($x['last_seen']??'1970-01-01'));return strtolower((string)($x['online']??''))==='yes'&&$seen!==false&&($now-$seen)<=600;}));
$blocked=0;$expired=0;foreach($licenses as $l){$st=license_state($l);if($st['state']==='EXPIRED')$expired++;elseif(!$st['allowed'])$blocked++;}
$apk=PANEL_ROOT.'/uploads/x1-latest.apk';$apkOk=is_file($apk)&&filesize($apk)>0;$dataOk=is_writable(DATA_DIR)&&is_file(CONFIG_FILE)&&is_file(STORE_FILE);$apiOk=is_file(PANEL_ROOT.'/api/ApiIPTV.php')&&extension_loaded('openssl');$health=($dataOk&&$apiOk)?'OPERACIONAL':'ATENÇÃO';
$lastErrors=array_reverse(array_slice($errors,-8));$lastDevices=$dev;usort($lastDevices,fn($a,$b)=>strcmp((string)($b['last_seen']??''),(string)($a['last_seen']??'')));$lastDevices=array_slice($lastDevices,0,8);
$alerts=x1_alerts();$unread=unread_notifications();$hh=(array)(store()['health_history']??[]);$lastHealth=$hh?end($hh):null;$openTasks=count(array_filter(ops_tasks(),fn($t)=>(string)($t['status']??'OPEN')!=='DONE'));top('Dashboard Operacional');
?>
<div class="ops-hero card"><div><div class="small">Estado X1</div><div class="big"><?=h($health)?></div><p class="small">API <?= $apiOk?'OK':'com problema' ?> · armazenamento <?= $dataOk?'OK':'com problema' ?> · APK <?= $apkOk?'publicada':'não publicada localmente' ?></p></div><div class="actions"><a class="btn" href="diagnostics.php">Diagnóstico completo</a><a class="btn secondary" href="logs.php">Ver logs</a></div></div>
<?php if($alerts):?><div class="card warn"><div class="card-head"><strong><?=count($alerts)?> alerta(s) ativo(s)</strong><a href="alerts.php">Abrir Centro de Alertas</a></div></div><?php endif?><div class="grid mt">
<?php foreach([
 ['Dispositivos',count($dev),'registados'],['Online agora',$online,'contacto ≤ 10 min'],['Licenças',count($licenses),$blocked.' bloqueadas · '.$expired.' expiradas'],['API 24h',count($recentLogs),count($errors).' falhas'],['Erro 24h',count($recentLogs)?number_format(count($errors)*100/count($recentLogs),1).'%':'0.0%','taxa de falhas'],['Latência p95',$p95.' ms','últimas 24h'],['Version code',$app['version_code']??'—','auto update: '.($app['apkautoupdate']??'—')],['APK local',$apkOk?number_format(filesize($apk)/1024/1024,1).' MB':'—',$apkOk?'publicada':'sem upload local'],['Notificações',$unread,'não lidas'],['Tarefas abertas',$openTasks,'operacionais'],['Último health',$lastHealth?(!empty($lastHealth['ok'])?'OK':'FALHA'):'—',$lastHealth['created_at']??'sem execução']
] as [$a,$b,$sub]):?><div class="card"><div class="small"><?=h($a)?></div><div class="big"><?=h($b)?></div><p class="small"><?=h($sub)?></p></div><?php endforeach?>
</div>
<div class="dashboard-cols mt">
<div class="card"><div class="card-head"><h2>Falhas API recentes</h2><a href="logs.php?kind=api" class="small">abrir logs</a></div><?php if(!$lastErrors):?><p class="ok">Sem falhas registadas nas últimas 24 horas.</p><?php else:?><table><tr><th>Hora</th><th>Tag</th><th>User</th><th>HTTP</th><th>ms</th></tr><?php foreach($lastErrors as $x):?><tr><td><?=h($x['created_at']??'')?></td><td><?=h($x['tag']??'')?></td><td><?=h($x['userid']??'')?></td><td><span class="badge inactive"><?=h($x['http_status']??'')?></span></td><td><?=h($x['duration_ms']??'')?></td></tr><?php endforeach?></table><?php endif?></div>
<div class="card"><div class="card-head"><h2>Últimos dispositivos</h2><a href="devices.php" class="small">ver todos</a></div><?php if(!$lastDevices):?><p class="small">Ainda não há dispositivos registados.</p><?php else:?><table><tr><th>User</th><th>App</th><th>Estado</th><th>Último contacto</th></tr><?php foreach($lastDevices as $x):$seen=strtotime((string)($x['last_seen']??'1970-01-01'));$on=strtolower((string)($x['online']??''))==='yes'&&$seen!==false&&($now-$seen)<=600;?><tr><td><?=h($x['userid']??'')?></td><td><?=h($x['app_name']??'')?></td><td><span class="badge <?=$on?'active':'inactive'?>"><?=$on?'ONLINE':'OFFLINE'?></span></td><td><?=h($x['last_seen']??'')?></td></tr><?php endforeach?></table><?php endif?></div>
</div>
<div class="card mt"><div class="card-head"><h2>Estado dos módulos</h2><a href="api_test.php" class="small">executar suite HTTP</a></div><div class="module-status">
<?php foreach([
 ['ApiIPTV.php',is_file(PANEL_ROOT.'/api/ApiIPTV.php')],['CloudBackup.php',is_file(PANEL_ROOT.'/api/CloudBackup.php')],['VPN',true],['TMDB',is_file(PANEL_ROOT.'/api/movies.php')],['Sports',is_file(PANEL_ROOT.'/api/sport.php')],['Intro',is_file(PANEL_ROOT.'/api/intro.mp4')],['Logo',is_file(PANEL_ROOT.'/api/logo.png')],['OpenSSL',extension_loaded('openssl')]
] as [$n,$ok]):?><span class="status-pill <?=$ok?'good':'bad'?>"><i></i><?=h($n)?></span><?php endforeach?>
</div></div>
<?php bottom();
