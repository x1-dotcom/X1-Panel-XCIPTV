# X1 Panel v2.2 — validação

## Editor visual de Perfis

Validado localmente em PHP 8.4 através do servidor HTTP integrado.

Cenário testado:

1. Instalação de administrador Owner.
2. Login real com sessão e CSRF.
3. Abertura de `admin/profiles.php`.
4. Criação de perfil pelo formulário visual com:
   - `theme = 2`
   - `app_language = es`
   - `language = Herdar`
   - Portal 2 = `https://portal2.example.test`
   - Portal 2 name = `X1 PT`
   - Live player = `VLC`
   - Live TV = Ativar
   - VOD = Desativar
   - VPN = Desativar
   - EXO hardware = Desativar
5. Atribuição do perfil ao `userid` de teste.
6. Pedido HTTP real a `ApiIPTV.php?tag=licV3&userid=...`.
7. Desencriptação AES do payload recebido.

Resultado observado no payload:

- `theme = 2`
- `app_language = es`
- `language = pt` (herdado do global, como esperado)
- `portal2 = https://portal2.example.test`
- `portal2_name = X1 PT`
- `player_tv = VLC`
- `btn_live = Yes`
- `btn_vod = No`
- `btn_vpn = no`
- `ort_settings.exo_hw = no`

Isto valida a cadeia **editor visual → persistência do perfil → atribuição → composição do overlay → licV3 cifrado → desencriptação**.

## Sintaxe

Todos os 49 ficheiros PHP passam `php -l`.

## Limite da validação

O preview do editor confirma a configuração composta no painel, mas não substitui a validação visual final numa APK Android real.
