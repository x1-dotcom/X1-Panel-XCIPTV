# Validação executada — X1 Panel

Data: 2026-08-18

## Validado anteriormente no motor atual

- `php -l` em todos os ficheiros PHP.
- instalação e login administrativo.
- páginas administrativas por HTTP.
- `licV3` desencriptado para JSON válido com 117 chaves `app`.
- alteração no admin refletida em `licV3`.
- `licV4` e respetivos blocos descodificados.
- `connv2` com JSON válido e registo do dispositivo.
- anúncio e mensagem individual refletidos nos endpoints.
- `conn`, `msg_conf`, `whatsup`, `gfilter`, `msg_cat_view`, `msg` e `man`.
- VPN admin → `vpnconfigV2` → AES desencriptado.
- Cloud Backup save/restore.
- `sport.php` em modo local/iframe.
- fallback de `movies.php` sem API key.

## Alterações X1 desta versão

- removidas as referências de branding antigas do código, defaults e documentação;
- `appname = X1` e `customerid = X1` nos defaults;
- removidos defaults externos de suporte/log pertencentes à marca anterior;
- logo oficial X1 incluído no painel e na API;
- intro oficial X1 incluída em `api/intro.mp4`;
- upload do logo sincroniza `assets/logo.png` e `api/logo.png`;
- página de Intro inclui preview do vídeo;
- login, instalação, menu e tema visual redesenhados para o ADN X1 (grafite, ciano e azul);
- Sports continua com provedor e API key editáveis.

## Ainda requer validação no servidor final

- chamadas externas reais a TMDB/TheSportsDB com as tuas keys;
- importação SQLite, caso uses dados de uma instalação anterior;
- execução da APK Android apontada para o domínio final.

## Teste de branding X1 desta build

- instalação: HTTP 302 / PASS;
- login: HTTP 302 / PASS;
- dashboard: HTTP 200 e identidade X1 presente / PASS;
- `licV4`: HTTP 200 + JSON válido / PASS;
- `connv2`: HTTP 200 + JSON válido / PASS;
- `api/intro.mp4`: HTTP 200 / PASS;
- `api/logo.png`: HTTP 200 / PASS;
- pesquisa global por branding antigo: 0 ocorrências / PASS.

## Personalização APK X1 (v1.4)

Validado por HTTP em 2026-08-18:
- página `admin/customize.php` carrega com os 4 temas reais da build (`d`, `1`, `2`, `3`);
- idiomas disponíveis: `en`, `ar`, `bn`, `zh`, `fr`, `hi`, `it`, `ml`, `pt`, `es`, `ru`, `sv`;
- POST de teste: Tema 2 + Espanhol + combinação de menus;
- `api/main.json` persistiu `theme=2`, `app_language=es`, `language=es`, `btn_live=Yes`, `btn_live2=No`, `btn_vpn=yes`;
- `licV3` foi chamado por HTTP, desencriptado com AES-128-CBC e devolveu exatamente os mesmos valores.

Os dados artificiais do teste foram removidos do pacote antes de empacotar.

## v1.5 — Gestor de funcionalidades
- PASS: página `admin/features.php` com flags reais do `main.json`.
- PASS: menus Live/EPG/VOD/Séries/Catch-up/Rádio/Conta/Favoritos/Multi-screen controláveis por portal 1–5.
- PASS: flags gerais de parental, gravação, VPN, notificações, update, signup, settings, mensagens, anúncios, user info, UDID, logs e comportamento de conteúdo.
- PASS: flags aninhadas VAST, AdMob, Prebid, EXO/VLC hardware e legendas.
- PASS: perfil "Painel na APK" mantém `panel=xtreamcodes` e desliga as entradas visuais relacionadas, evitando valores de provider não observados na build.
- PASS: admin -> main.json -> licV3 AES -> decrypt confirmou valores idênticos.

## Validação v1.6

Executado localmente por HTTP em PHP 8.4:

- PASS: criar perfil pelo admin e persistir overrides.
- PASS: criar licença pelo admin e atribuir perfil.
- PASS: `licV3` cifrado/desencriptado refletiu `theme=3`, `app_language=es`, portal personalizado e `btn_vpn=no` do perfil.
- PASS: dispositivo registado por `connv2` e automaticamente associado a licença ACTIVE.
- PASS: bloquear dispositivo pelo admin refletiu `success=0` + `license_status=BLOCKED` em `connv2`.
- PASS: bloqueio refletiu `success=0` + `status=BLOCKED` em `licV4`.
- PASS: licença ACTIVE com data passada refletiu `status=EXPIRED` automaticamente em `licV4`.
- PASS: sintaxe PHP de todos os ficheiros.

## Validação v1.7

- Backup X1: geração de payload `X1_PANEL_BACKUP` v1 — PASS
- Restore X1: alteração de configuração -> restore -> valor original recuperado — PASS
- Upload HTTP de APK e atualização automática de `apkurl`/`version_code` — PASS durante desenvolvimento
- SHA-256 da APK alojada — implementado
- Logs API: filtros + exportação CSV — implementado
- Auditoria administrativa — implementada
- `php -l`: PASS em 40 ficheiros PHP

Os dados artificiais usados nos testes foram removidos antes do empacotamento.

## Validação v1.8

Executado localmente por HTTP em PHP 8.4 em 2026-08-18:

- PASS: instalação com CSRF e criação do administrador.
- PASS: login com CSRF.
- PASS: tentativas inválidas decrementam o contador 4 → 3 → 2 → 1.
- PASS: quinta tentativa inválida ativa bloqueio temporário de 15 minutos.
- PASS: bloqueio fica persistido em `store.json` por utilizador + IP.
- PASS: após limpeza do bloqueio, credenciais válidas abrem o Dashboard Operacional.
- PASS: página `admin/security.php` autenticada e configuração de rate-limit/sessões persistida.
- PASS: página `admin/diagnostics.php` autenticada, reconhece as 117 chaves `app` e verifica saúde local.
- PASS: chamadas reais `licV4` e `connv2` alimentam os logs e o Dashboard Operacional.
- PASS: `connv2` recente aparece em “Online agora” e em “Últimos dispositivos”.
- PASS: auditoria de login/logout/password/política de segurança implementada.
- PASS: `php -l` em 42 ficheiros PHP.

Não foi necessário alterar `ApiIPTV.php`, `CloudBackup.php` nem o formato da licença para implementar a v1.8; o contrato da APK permanece igual ao da v1.7.
