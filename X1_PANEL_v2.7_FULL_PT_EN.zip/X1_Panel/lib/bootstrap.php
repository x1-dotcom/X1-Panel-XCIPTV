<?php
declare(strict_types=1);
require_once __DIR__.'/i18n.php';
ui_i18n_start();
const PANEL_ROOT=__DIR__.'/..';
const DATA_DIR=PANEL_ROOT.'/data';
const CONFIG_FILE=DATA_DIR.'/config.json';
const STORE_FILE=DATA_DIR.'/store.json';
const API_KEY='mysecretkeywsdef';
const API_IV='myuniqueivparamu';
if(!is_dir(DATA_DIR)) @mkdir(DATA_DIR,0775,true);
function jread(string $f,array $d=[]):array{if(!is_file($f))return$d;$j=json_decode((string)file_get_contents($f),true);return is_array($j)?$j:$d;}
function jwrite(string $f,array $v):void{$tmp=$f.'.tmp';$json=json_encode($v,JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);if($json===false)throw new RuntimeException('JSON encode failed');if(file_put_contents($tmp,$json,LOCK_EX)===false)throw new RuntimeException('Cannot write '.$f);if(!rename($tmp,$f))throw new RuntimeException('Cannot replace '.$f);@chmod($f,0664);}
function x1_seed():array{$j=jread(DATA_DIR.'/seed_main.json',[]);return isset($j['app'])&&is_array($j['app'])?$j:[];}
function conn_seed():array{return jread(DATA_DIR.'/seed_connv2.json',['tag'=>'connv2','success'=>'1','api_ver'=>'1.0v','message'=>'','msgid'=>'1646','msg_status'=>'INACTIVE','msg_expire'=>'','announcement'=>'','ann_status'=>'INACTIVE','ann_expire'=>'','ann_interval'=>'2','ann_disappear'=>'1']);}
function default_config():array{$w=x1_seed();if(!$w)$w=['tag'=>'licV3','success'=>'1','api_ver'=>'2.0v','which'=>'licV3','app'=>[]];return ['tag'=>$w['tag']??'licV3','success'=>$w['success']??'1','api_ver'=>$w['api_ver']??'2.0v','which'=>$w['which']??'licV3','app'=>$w['app']??[],'connv2'=>conn_seed()];}
function config():array{if(!is_file(CONFIG_FILE))save_config(default_config());$base=default_config();$c=jread(CONFIG_FILE,$base);$out=$base;$out['tag']=$c['tag']??$base['tag'];$out['success']=$c['success']??$base['success'];$out['api_ver']=$c['api_ver']??$base['api_ver'];$out['which']=$c['which']??$base['which'];$out['app']=array_replace_recursive($base['app']??[],$c['app']??[]);$out['connv2']=array_replace_recursive($base['connv2']??[],$c['connv2']??[]);return$out;}
function save_config(array $c):void{
 $before=is_file(CONFIG_FILE)?jread(CONFIG_FILE,[]):[];
 jwrite(CONFIG_FILE,$c);sync_legacy_json($c);
 if(!empty($_SESSION['admin_id'])&&$before!==$c)audit_config_diff($before,$c);
}
function sync_legacy_json(array $c):void{jwrite(PANEL_ROOT.'/api/main.json',['tag'=>$c['tag']??'licV3','success'=>$c['success']??'1','api_ver'=>$c['api_ver']??'2.0v','which'=>$c['which']??'licV3','app'=>$c['app']??[]]);jwrite(PANEL_ROOT.'/api/connv2.json',$c['connv2']??[]);}
function store():array{$d=['admins'=>[],'messages'=>[],'devices'=>[],'backups'=>[],'vpn'=>[],'logs'=>[],'tmdb'=>['api_key'=>'','language'=>'pt-PT'],'sports'=>['provider'=>'tvsportguide','api_key'=>'','auto_s'=>'','custom_url'=>'','sport'=>'Soccer','header_n'=>'Sports','border_c'=>'#222222','background_c'=>'#000000','text_c'=>'#ffffff','days'=>7],'licenses'=>[],'profiles'=>[],'audit'=>[],'login_attempts'=>[],'security'=>['max_attempts'=>5,'window_minutes'=>15,'lock_minutes'=>15,'idle_minutes'=>30,'absolute_hours'=>12],'maintenance_schedule'=>['enabled'=>false,'start_at'=>'','end_at'=>'','message'=>''],'alert_dismissals'=>[],'notifications'=>[],'health_history'=>[],'health_settings'=>['enabled'=>false,'token'=>'','keep'=>200],'apk_versions'=>[],'ops_tasks'=>[],'compat_deliveries'=>[],'profile_presets'=>[],'android_tests'=>[]];$s=jread(STORE_FILE,$d);return array_replace_recursive($d,$s);}
function save_store(array $s):void{jwrite(STORE_FILE,$s);}function rows(string $k):array{$s=store();return is_array($s[$k]??null)?$s[$k]:[];}function setrows(string $k,array $v):void{$s=store();$s[$k]=array_values($v);save_store($s);}function nextid(array $a):int{$m=0;foreach($a as $r)$m=max($m,(int)($r['id']??0));return$m+1;}
function upsert_row(string $k,string $key,string $value,array $row):array{$s=store();$a=is_array($s[$k]??null)?$s[$k]:[];$found=false;foreach($a as &$r){if((string)($r[$key]??'')===$value){$row['id']=$r['id']??($row['id']??nextid($a));$r=array_merge($r,$row);$found=true;break;}}unset($r);if(!$found){$row['id']=$row['id']??nextid($a);$a[]=$row;}$s[$k]=$a;save_store($s);return$row;}
function delete_row(string $k,string $key,string $value):void{setrows($k,array_values(array_filter(rows($k),fn($r)=>(string)($r[$key]??'')!==$value)));}
function find_row(string $k,string $key,string $value):?array{foreach(rows($k) as $r)if((string)($r[$key]??'')===$value)return$r;return null;}
function json_response(array $d,int $st=200):never{http_response_code($st);header('Content-Type: application/json; charset=utf-8');echo json_encode($d,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);exit;}
function enc_xor_b64(string $str,string $key):string{$o='';if($key==='')return base64_encode($str);$n=strlen($key);for($i=0,$l=strlen($str);$i<$l;$i++)$o.=chr(ord($str[$i])^ord($key[$i%$n]));return base64_encode($o);}function aes_hex(string $p):string{$x=openssl_encrypt($p,'AES-128-CBC',API_KEY,OPENSSL_RAW_DATA,API_IV);return bin2hex($x===false?'':$x);}function aes_decrypt_hex(string $hex):string{$raw=@hex2bin($hex);if($raw===false)return'';$p=openssl_decrypt($raw,'AES-128-CBC',API_KEY,OPENSSL_RAW_DATA,API_IV);return$p===false?'':$p;}
function p(string $n,string $d=''):string{$v=$_REQUEST[$n]??$d;return is_scalar($v)?trim((string)$v):$d;}function client_ip():string{return $_SERVER['REMOTE_ADDR']??'';}function now():string{return date('Y-m-d H:i:s');}
function log_api(string $tag,string $u,int $http,string $succ,string $detail='',?float $started=null):void{$a=rows('logs');$a[]=['id'=>nextid($a),'created_at'=>now(),'tag'=>$tag,'userid'=>$u,'method'=>$_SERVER['REQUEST_METHOD']??'CLI','ip'=>client_ip(),'http_status'=>$http,'success'=>$succ,'duration_ms'=>$started?(int)round((microtime(true)-$started)*1000):0,'detail'=>$detail];if(count($a)>5000)$a=array_slice($a,-5000);setrows('logs',$a);}
function security_headers():void{if(headers_sent())return;header('X-Content-Type-Options: nosniff');header('X-Frame-Options: DENY');header('Referrer-Policy: same-origin');header('Permissions-Policy: camera=(), microphone=(), geolocation=()');header('Cross-Origin-Opener-Policy: same-origin');}
function security_defaults():array{return ['max_attempts'=>5,'window_minutes'=>15,'lock_minutes'=>15,'idle_minutes'=>30,'absolute_hours'=>12];}
function security_config():array{$s=store();return array_replace(security_defaults(),is_array($s['security']??null)?$s['security']:[]);}
function save_security_config(array $cfg):void{$s=store();$s['security']=array_replace(security_defaults(),$cfg);save_store($s);}
function ensure_session():void{
 security_headers();
 if(session_status()!==PHP_SESSION_ACTIVE){
  @ini_set('session.use_strict_mode','1');@ini_set('session.use_only_cookies','1');
  session_name('X1SESSID');
  session_set_cookie_params(['httponly'=>true,'samesite'=>'Strict','secure'=>(!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off'),'path'=>'/']);
  session_start();
 }
 if(!empty($_SESSION['admin_id'])){
  $sec=security_config();$now=time();$idle=max(5,(int)$sec['idle_minutes'])*60;$absolute=max(1,(int)$sec['absolute_hours'])*3600;
  $last=(int)($_SESSION['last_activity']??$now);$started=(int)($_SESSION['auth_started']??$now);
  if(($now-$last)>$idle||($now-$started)>$absolute){
   $_SESSION=[];if(ini_get('session.use_cookies')){$cp=session_get_cookie_params();setcookie(session_name(),'',time()-42000,$cp['path'],$cp['domain']??'',(bool)$cp['secure'],(bool)$cp['httponly']);}
   session_destroy();session_start();$_SESSION['session_expired']=true;return;
  }
  $_SESSION['last_activity']=$now;
 }
}
function current_admin():?array{ensure_session();$id=(string)($_SESSION['admin_id']??'');return $id===''?null:find_row('admins','id',$id);}
function admin_role(?array $a=null):string{$a=$a??current_admin();$r=strtolower((string)($a['role']??'owner'));return in_array($r,['owner','admin','operator','viewer'],true)?$r:'viewer';}
function admin_active(?array $a=null):bool{$a=$a??current_admin();return $a!==null&&strtoupper((string)($a['status']??'ACTIVE'))!=='INACTIVE';}
function admin_page_permission(string $page):string{
 $map=['admins.php'=>'admins','security.php'=>'security','panel_backup.php'=>'backup','migration.php'=>'backup','updates.php'=>'updates','licenses.php'=>'access','profiles.php'=>'access','devices.php'=>'access','apk_lab.php'=>'diagnostics','logs.php'=>'logs','diagnostics.php'=>'diagnostics','api_test.php'=>'diagnostics','alerts.php'=>'alerts','notifications.php'=>'alerts','health.php'=>'diagnostics','ops_tasks.php'=>'config'];
 return $map[$page]??'config';
}
function admin_can(string $perm,?array $a=null):bool{
 $role=admin_role($a);if($role==='owner')return true;
 $allow=[
  'admin'=>['config','access','updates','backup','logs','diagnostics','alerts','security'],
  'operator'=>['config','access','updates','logs','diagnostics','alerts'],
  'viewer'=>['config','access','updates','logs','diagnostics','alerts']
 ];return in_array($perm,$allow[$role]??[],true);
}
function admin_can_write(string $perm,?array $a=null):bool{$role=admin_role($a);if($role==='viewer')return false;if($perm==='admins')return $role==='owner';if($perm==='security')return in_array($role,['owner','admin'],true);if($perm==='backup')return in_array($role,['owner','admin'],true);return admin_can($perm,$a);}
function is_admin():bool{ensure_session();return!empty($_SESSION['admin_id'])&&admin_active();}
function require_admin():void{
 if(!is_admin()){header('Location: login.php');exit;}
 $page=basename((string)($_SERVER['SCRIPT_NAME']??''));$perm=admin_page_permission($page);
 if(!admin_can($perm)){http_response_code(403);exit('Sem permissão para esta área.');}
 if(($_SERVER['REQUEST_METHOD']??'GET')==='POST'&&!admin_can_write($perm)){http_response_code(403);exit('Conta apenas de leitura.');}
}
function csrf_token():string{ensure_session();if(empty($_SESSION['csrf']))$_SESSION['csrf']=bin2hex(random_bytes(24));return$_SESSION['csrf'];}
function csrf_check():void{ensure_session();if(!hash_equals($_SESSION['csrf']??'',(string)($_POST['csrf']??''))){http_response_code(403);exit('Invalid CSRF token');}}
function h(mixed $v):string{return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
function login_attempt_key(string $username,string $ip):string{return hash('sha256',strtolower(trim($username)).'|'.$ip);}
function login_guard(string $username,string $ip):array{
 $sec=security_config();$key=login_attempt_key($username,$ip);$row=find_row('login_attempts','key',$key);$now=time();
 if(!$row)return ['allowed'=>true,'remaining'=>(int)$sec['max_attempts'],'locked_until'=>0];
 $locked=(int)($row['locked_until']??0);if($locked>$now)return ['allowed'=>false,'remaining'=>0,'locked_until'=>$locked];
 $window=max(1,(int)$sec['window_minutes'])*60;$attempts=array_values(array_filter((array)($row['attempts']??[]),fn($t)=>(int)$t>=($now-$window)));
 return ['allowed'=>true,'remaining'=>max(0,(int)$sec['max_attempts']-count($attempts)),'locked_until'=>0];
}
function login_record_failure(string $username,string $ip):array{
 $sec=security_config();$key=login_attempt_key($username,$ip);$row=find_row('login_attempts','key',$key)??['key'=>$key,'username'=>$username,'ip'=>$ip,'attempts'=>[],'locked_until'=>0];$now=time();$window=max(1,(int)$sec['window_minutes'])*60;
 $attempts=array_values(array_filter((array)($row['attempts']??[]),fn($t)=>(int)$t>=($now-$window)));$attempts[]=$now;$locked=0;
 if(count($attempts)>=(int)$sec['max_attempts'])$locked=$now+max(1,(int)$sec['lock_minutes'])*60;
 $row=array_merge($row,['username'=>$username,'ip'=>$ip,'attempts'=>$attempts,'locked_until'=>$locked,'updated_at'=>now()]);upsert_row('login_attempts','key',$key,$row);
 return ['locked'=>$locked>$now,'locked_until'=>$locked,'remaining'=>max(0,(int)$sec['max_attempts']-count($attempts))];
}
function login_clear_failures(string $username,string $ip):void{delete_row('login_attempts','key',login_attempt_key($username,$ip));}
function prune_login_attempts():void{$now=time();$sec=security_config();$keep=max((int)$sec['window_minutes'],(int)$sec['lock_minutes'])*60*2;$out=[];foreach(rows('login_attempts') as $r){$a=array_values((array)($r['attempts']??[]));$last=$a?(int)$a[count($a)-1]:0;if(($last>0&&$now-$last<$keep)||(int)($r['locked_until']??0)>$now)$out[]=$r;}setrows('login_attempts',$out);}
function upload_asset(string $field,string $target,array $exts,int $max):array{if(empty($_FILES[$field]))return[false,'Nenhum ficheiro enviado.'];$f=$_FILES[$field];if(($f['error']??1)!==UPLOAD_ERR_OK)return[false,'Falha no upload.'];if((int)$f['size']>$max)return[false,'Ficheiro demasiado grande.'];$ext=strtolower(pathinfo((string)$f['name'],PATHINFO_EXTENSION));if(!in_array($ext,$exts,true))return[false,'Formato não permitido.'];if(!move_uploaded_file((string)$f['tmp_name'],$target))return[false,'Não foi possível guardar.'];return[true,'Ficheiro atualizado.'];}

function parse_dt(string $v):?int{$v=trim($v);if($v==='')return null;$t=strtotime($v);return $t===false?null:$t;}
function license_for_user(string $userid):?array{return $userid===''?null:find_row('licenses','userid',$userid);}
function license_state(?array $lic):array{if(!$lic)return ['state'=>'INHERIT','allowed'=>true,'reason'=>''];$status=strtoupper(trim((string)($lic['status']??'ACTIVE')));if(in_array($status,['BLOCKED','INACTIVE','SUSPENDED'],true))return ['state'=>$status,'allowed'=>false,'reason'=>(string)($lic['reason']??'Acesso desativado')];$exp=parse_dt((string)($lic['expires_at']??''));if($exp!==null&&$exp<time())return ['state'=>'EXPIRED','allowed'=>false,'reason'=>'Licença expirada'];return ['state'=>'ACTIVE','allowed'=>true,'reason'=>''];}
function profile_by_id(string $id):?array{return $id===''?null:find_row('profiles','id',$id);}
function effective_config_for_user(string $userid):array{$c=config();$lic=license_for_user($userid);if(!$lic)return $c;$pid=(string)($lic['profile_id']??'');$pr=profile_by_id($pid);if(!$pr)return $c;$ov=$pr['app_overrides']??[];if(is_string($ov)){$d=json_decode($ov,true);$ov=is_array($d)?$d:[];}if(is_array($ov))$c['app']=array_replace_recursive($c['app']??[],$ov);return $c;}
function ensure_device_license(string $userid):void{if($userid===''||license_for_user($userid))return;upsert_row('licenses','userid',$userid,['userid'=>$userid,'status'=>'ACTIVE','expires_at'=>'','profile_id'=>'','notes'=>'','reason'=>'','created_at'=>now(),'updated_at'=>now()]);}
function user_allowed(string $userid):array{return license_state(license_for_user($userid));}

function config_fingerprint(array $app):string{
 $keys=['theme','app_language','language','portal','portal2','portal3','portal4','portal5','btn_live','btn_vod','btn_series','btn_epg','btn_catchup','btn_radio','btn_vpn','btn_noti','btn_update'];
 $v=[];foreach($keys as $k)$v[$k]=$app[$k]??null;return substr(hash('sha256',json_encode($v,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE)),0,16);
}
function record_compat_delivery(string $userid,string $endpoint,array $app):void{
 if($userid==='')return;$s=store();$a=is_array($s['compat_deliveries']??null)?$s['compat_deliveries']:[];
 $lic=license_for_user($userid);$pr=$lic?profile_by_id((string)($lic['profile_id']??'')):null;
 $a[]=['id'=>nextid($a),'created_at'=>now(),'userid'=>$userid,'endpoint'=>$endpoint,'fingerprint'=>config_fingerprint($app),'theme'=>(string)($app['theme']??''),'language'=>(string)($app['app_language']??($app['language']??'')),'profile'=>(string)($pr['name']??'Global'),'version_code'=>(string)($app['version_code']??'')];
 if(count($a)>3000)$a=array_slice($a,-3000);$s['compat_deliveries']=$a;save_store($s);
}
function last_compat_delivery(string $userid):?array{$a=array_values(array_filter(rows('compat_deliveries'),fn($x)=>(string)($x['userid']??'')===$userid));if(!$a)return null;usort($a,fn($x,$y)=>strcmp((string)($y['created_at']??''),(string)($x['created_at']??'')));return$a[0];}
function compat_status_for_user(string $userid):array{
 $d=find_row('devices','userid',$userid);$sent=last_compat_delivery($userid);if(!$sent)return ['state'=>'NOT_SENT','label'=>'Ainda não entregue','detail'=>'Este userid ainda não pediu licV3/licV4.'];
 $seen=(string)($d['last_seen']??'');$sentAt=(string)($sent['created_at']??'');if($seen!==''&&$seen>=$sentAt)return ['state'=>'CALLBACK','label'=>'Callback após entrega','detail'=>'A APK pediu licença e voltou a comunicar por connv2.'];
 return ['state'=>'SENT','label'=>'Entregue, sem callback posterior','detail'=>'O servidor entregou a configuração; ainda não há connv2 posterior.'];
}
function x1_profile_presets():array{return [
 'complete'=>['name'=>'Completo','description'=>'Todas as áreas principais ativas.','overrides'=>['btn_live'=>'yes','btn_vod'=>'yes','btn_series'=>'yes','btn_epg'=>'yes','btn_catchup'=>'yes','btn_radio'=>'yes','btn_fav'=>'yes','btn_vpn'=>'yes','btn_noti'=>'yes']],
 'minimal'=>['name'=>'Minimal','description'=>'Interface simples: Live, VOD e Séries.','overrides'=>['btn_live'=>'yes','btn_vod'=>'yes','btn_series'=>'yes','btn_epg'=>'no','btn_catchup'=>'no','btn_radio'=>'no','btn_fav'=>'yes','btn_vpn'=>'no','btn_noti'=>'no']],
 'iptv_only'=>['name'=>'Só IPTV','description'=>'Live TV e EPG, sem VOD/Séries.','overrides'=>['btn_live'=>'yes','btn_vod'=>'no','btn_series'=>'no','btn_epg'=>'yes','btn_catchup'=>'yes','btn_radio'=>'no','btn_fav'=>'yes']],
 'kids'=>['name'=>'Kids','description'=>'Perfil reduzido com parental ativo e extras ocultos.','overrides'=>['btn_live'=>'yes','btn_vod'=>'yes','btn_series'=>'yes','btn_epg'=>'no','btn_catchup'=>'no','btn_radio'=>'no','btn_vpn'=>'no','btn_update'=>'no','settings_account'=>'no','settings_app'=>'no']]
];}

function base_url():string{$https=!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off';$host=$_SERVER['HTTP_HOST']??'localhost';$script=$_SERVER['SCRIPT_NAME']??'';$root=preg_replace('#/admin/[^/]+$#','',$script);return($https?'https':'http').'://'.$host.rtrim((string)$root,'/');}
if(!is_file(CONFIG_FILE))save_config(default_config());else sync_legacy_json(config());if(!is_file(STORE_FILE))save_store(store());

function x1_panel_backup_payload():array{
    $files=[];
    foreach(['assets/logo.png','api/logo.png','api/intro.mp4'] as $rel){
        $path=PANEL_ROOT.'/'.$rel;
        if(is_file($path)){$raw=file_get_contents($path);if($raw!==false)$files[$rel]=base64_encode($raw);}
    }
    return [
        'format'=>'X1_PANEL_BACKUP','version'=>1,'created_at'=>date(DATE_ATOM),
        'config'=>config(),'store'=>store(),'files'=>$files
    ];
}
function x1_panel_backup_json():string{
    $j=json_encode(x1_panel_backup_payload(),JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);
    if($j===false)throw new RuntimeException('Não foi possível criar backup.');
    return $j;
}
function x1_restore_panel_backup(array $b):void{
    if(($b['format']??'')!=='X1_PANEL_BACKUP'||(int)($b['version']??0)!==1)throw new RuntimeException('Backup X1 inválido ou incompatível.');
    if(!isset($b['config'])||!is_array($b['config'])||!isset($b['store'])||!is_array($b['store']))throw new RuntimeException('Backup incompleto.');
    save_config($b['config']);
    save_store($b['store']);
    foreach(($b['files']??[]) as $rel=>$encoded){
        if(!in_array($rel,['assets/logo.png','api/logo.png','api/intro.mp4'],true)||!is_string($encoded))continue;
        $raw=base64_decode($encoded,true);if($raw===false)continue;
        $path=PANEL_ROOT.'/'.$rel;@mkdir(dirname($path),0775,true);file_put_contents($path,$raw,LOCK_EX);
    }
    audit_log('panel_backup_restore','Backup completo do painel restaurado');
}
function audit_log(string $action,string $detail=''):void{
    $a=rows('audit');
    $a[]=['id'=>nextid($a),'created_at'=>now(),'admin_id'=>$_SESSION['admin_id']??'','action'=>$action,'ip'=>client_ip(),'detail'=>$detail];
    if(count($a)>5000)$a=array_slice($a,-5000);
    setrows('audit',$a);
}

function maintenance_schedule():array{$s=store();return array_replace(['enabled'=>false,'start_at'=>'','end_at'=>'','message'=>''],is_array($s['maintenance_schedule']??null)?$s['maintenance_schedule']:[]);}
function save_maintenance_schedule(array $v):void{$s=store();$s['maintenance_schedule']=array_replace(['enabled'=>false,'start_at'=>'','end_at'=>'','message'=>''],$v);save_store($s);}
function effective_maintenance(array $app):array{
 $base=['active'=>strtoupper((string)($app['mnt_status']??'INACTIVE'))==='ACTIVE','status'=>(string)($app['mnt_status']??'INACTIVE'),'message'=>(string)($app['mnt_message']??''),'expire'=>(string)($app['mnt_expire']??''),'scheduled'=>false];
 $sch=maintenance_schedule();if(empty($sch['enabled']))return $base;$now=time();$st=parse_dt((string)($sch['start_at']??''));$en=parse_dt((string)($sch['end_at']??''));$inside=($st===null||$now>=$st)&&($en===null||$now<=$en);
 if(!$inside)return $base;return ['active'=>true,'status'=>'ACTIVE','message'=>(string)($sch['message']?:($app['mnt_message']??'')),'expire'=>(string)($sch['end_at']??($app['mnt_expire']??'')),'scheduled'=>true];
}
function x1_alerts():array{
 $a=[];$now=time();$logs=rows('logs');$cut=$now-86400;$recent=array_values(array_filter($logs,fn($x)=>strtotime((string)($x['created_at']??'1970-01-01'))>=$cut));$err=array_values(array_filter($recent,fn($x)=>(int)($x['http_status']??0)>=400||in_array(strtoupper((string)($x['success']??'')),['0','FALSE','FAIL','ERROR'],true)));
 if($recent&&count($err)/count($recent)>=.10)$a[]=['id'=>'api_error_rate','level'=>'danger','title'=>'Taxa de erro API elevada','detail'=>number_format(count($err)*100/count($recent),1).'% nas últimas 24 horas'];
 foreach(rows('licenses') as $l){$st=license_state($l);if($st['state']==='EXPIRED'){$a[]=['id'=>'expired_'.($l['userid']??''),'level'=>'warn','title'=>'Licença expirada','detail'=>(string)($l['userid']??'')];if(count($a)>12)break;}}
 $apk=PANEL_ROOT.'/uploads/x1-latest.apk';if(!is_file($apk))$a[]=['id'=>'apk_missing','level'=>'warn','title'=>'APK local não publicada','detail'=>'Faz upload no módulo Atualização remota.'];
 if(!is_writable(DATA_DIR))$a[]=['id'=>'data_not_writable','level'=>'danger','title'=>'Diretório de dados sem escrita','detail'=>DATA_DIR];
 if(!extension_loaded('openssl'))$a[]=['id'=>'openssl_missing','level'=>'danger','title'=>'OpenSSL indisponível','detail'=>'As licenças cifradas não funcionarão.'];
 $m=effective_maintenance(config()['app']??[]);if($m['active'])$a[]=['id'=>'maintenance_active','level'=>'info','title'=>'Manutenção ativa','detail'=>$m['message'].($m['scheduled']?' (programada)':'')];
 $dismiss=(array)(store()['alert_dismissals']??[]);return array_values(array_filter($a,fn($x)=>!in_array($x['id'],$dismiss,true)));
}
function dismiss_alert(string $id):void{$s=store();$d=array_values(array_unique(array_merge((array)($s['alert_dismissals']??[]),[$id])));$s['alert_dismissals']=array_slice($d,-200);save_store($s);}


function health_settings():array{
 $s=store();$h=array_replace(['enabled'=>false,'token'=>'','keep'=>200],is_array($s['health_settings']??null)?$s['health_settings']:[]);
 if(trim((string)$h['token'])===''){$h['token']=bin2hex(random_bytes(24));$s['health_settings']=$h;save_store($s);}return $h;
}
function save_health_settings(array $v):void{$s=store();$cur=health_settings();$s['health_settings']=array_replace($cur,$v);save_store($s);}
function x1_local_health():array{
 $c=config();$app=$c['app']??[];$items=[];
 $push=function(string $id,string $label,bool $ok,string $detail='')use(&$items){$items[]=['id'=>$id,'label'=>$label,'ok'=>$ok,'detail'=>$detail];};
 $push('php','PHP 8.1+',version_compare(PHP_VERSION,'8.1.0','>='),PHP_VERSION);
 $push('openssl','OpenSSL',extension_loaded('openssl'),extension_loaded('openssl')?'carregado':'em falta');
 $push('data','Data gravável',is_dir(DATA_DIR)&&is_writable(DATA_DIR),DATA_DIR);
 $push('config','Configuração',is_file(CONFIG_FILE)&&is_array(jread(CONFIG_FILE,[])),'config.json');
 $push('store','Armazenamento',is_file(STORE_FILE)&&is_array(jread(STORE_FILE,[])),'store.json');
 $push('api','ApiIPTV',is_file(PANEL_ROOT.'/api/ApiIPTV.php'),'api/ApiIPTV.php');
 $push('backup_api','Cloud Backup',is_file(PANEL_ROOT.'/api/CloudBackup.php'),'api/CloudBackup.php');
 $push('logo','Logo X1',is_file(PANEL_ROOT.'/api/logo.png')&&filesize(PANEL_ROOT.'/api/logo.png')>0,'api/logo.png');
 $push('intro','Intro X1',is_file(PANEL_ROOT.'/api/intro.mp4')&&filesize(PANEL_ROOT.'/api/intro.mp4')>0,'api/intro.mp4');
 $apk=PANEL_ROOT.'/uploads/x1-latest.apk';$push('apk','APK publicada',is_file($apk)&&filesize($apk)>0,is_file($apk)?number_format(filesize($apk)/1024/1024,2).' MB':'sem APK local');
 $push('params','117 parâmetros',count($app)===117,'encontrados: '.count($app));
 $fail=count(array_filter($items,fn($x)=>!$x['ok']));return ['created_at'=>now(),'ok'=>$fail===0,'failures'=>$fail,'items'=>$items];
}
function record_health_check(string $source='manual'):array{$r=x1_local_health();$r['source']=$source;$s=store();$a=is_array($s['health_history']??null)?$s['health_history']:[];$a[]=$r;$keep=max(20,(int)(health_settings()['keep']??200));if(count($a)>$keep)$a=array_slice($a,-$keep);$s['health_history']=$a;save_store($s);return$r;}
function notify(string $type,string $title,string $detail='',string $level='info'):void{$s=store();$a=is_array($s['notifications']??null)?$s['notifications']:[];$a[]=['id'=>nextid($a),'created_at'=>now(),'type'=>$type,'title'=>$title,'detail'=>$detail,'level'=>$level,'read'=>false];if(count($a)>500)$a=array_slice($a,-500);$s['notifications']=$a;save_store($s);}
function unread_notifications():int{return count(array_filter(rows('notifications'),fn($x)=>empty($x['read'])));}
function mark_notification_read(string $id):void{$s=store();foreach($s['notifications'] as &$n)if((string)($n['id']??'')===$id)$n['read']=true;unset($n);save_store($s);}
function apk_versions():array{$s=store();return is_array($s['apk_versions']??null)?$s['apk_versions']:[];}
function add_apk_version(array $meta):void{$s=store();$a=is_array($s['apk_versions']??null)?$s['apk_versions']:[];$meta['id']=$meta['id']??nextid($a);$a[]=$meta;$s['apk_versions']=$a;save_store($s);}
function archive_current_apk(string $label=''):?array{$src=PANEL_ROOT.'/uploads/x1-latest.apk';if(!is_file($src)||filesize($src)<=0)return null;$dir=PANEL_ROOT.'/uploads/versions';@mkdir($dir,0775,true);$stamp=date('Ymd_His');$file='x1_'.$stamp.'_'.substr(hash_file('sha256',$src),0,8).'.apk';$dst=$dir.'/'.$file;if(!copy($src,$dst))return null;$c=config();$m=['created_at'=>now(),'version_code'=>(string)($c['app']['version_code']??''),'file'=>'uploads/versions/'.$file,'sha256'=>hash_file('sha256',$dst),'size'=>filesize($dst),'label'=>$label];add_apk_version($m);return$m;}
function ops_tasks():array{$s=store();return is_array($s['ops_tasks']??null)?$s['ops_tasks']:[];}


function base32_encode_x1(string $data):string{
 $alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';$bits='';$out='';
 for($i=0;$i<strlen($data);$i++)$bits.=str_pad(decbin(ord($data[$i])),8,'0',STR_PAD_LEFT);
 foreach(str_split($bits,5) as $chunk){$chunk=str_pad($chunk,5,'0',STR_PAD_RIGHT);$out.=$alphabet[bindec($chunk)];}
 return $out;
}
function base32_decode_x1(string $s):string{
 $alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';$s=strtoupper(preg_replace('/[^A-Z2-7]/','',$s));$bits='';$out='';
 for($i=0;$i<strlen($s);$i++){$p=strpos($alphabet,$s[$i]);if($p===false)continue;$bits.=str_pad(decbin($p),5,'0',STR_PAD_LEFT);}
 foreach(str_split($bits,8) as $b)if(strlen($b)===8)$out.=chr(bindec($b));return $out;
}
function totp_secret():string{return base32_encode_x1(random_bytes(20));}
function totp_code(string $secret,?int $time=null):string{
 $counter=intdiv($time??time(),30);$bin=pack('N2',($counter>>32)&0xffffffff,$counter&0xffffffff);$hash=hash_hmac('sha1',$bin,base32_decode_x1($secret),true);$o=ord($hash[19])&15;$v=((ord($hash[$o])&127)<<24)|((ord($hash[$o+1])&255)<<16)|((ord($hash[$o+2])&255)<<8)|(ord($hash[$o+3])&255);return str_pad((string)($v%1000000),6,'0',STR_PAD_LEFT);
}
function totp_verify(string $secret,string $code,int $window=1):bool{$code=preg_replace('/\D/','',$code);if(strlen($code)!==6)return false;for($i=-$window;$i<=$window;$i++)if(hash_equals(totp_code($secret,time()+$i*30),$code))return true;return false;}
function admin_ip_allowed(array $a,string $ip):bool{$raw=trim((string)($a['allowed_ips']??''));if($raw==='')return true;$ips=preg_split('/[\s,;]+/',$raw,-1,PREG_SPLIT_NO_EMPTY);return in_array($ip,$ips,true);}
function complete_admin_login(array $r):void{session_regenerate_id(true);$_SESSION['admin_id']=$r['id'];$_SESSION['admin_user']=$r['username'];$_SESSION['admin_role']=admin_role($r);$_SESSION['auth_started']=time();$_SESSION['last_activity']=time();$_SESSION['csrf']=bin2hex(random_bytes(24));unset($_SESSION['pending_2fa']);}
function flatten_x1(array $a,string $prefix=''):array{$o=[];foreach($a as $k=>$v){$key=$prefix===''?(string)$k:$prefix.'.'.$k;if(is_array($v))$o+=flatten_x1($v,$key);else$o[$key]=$v;}return$o;}
function audit_config_diff(array $before,array $after):void{
 $b=flatten_x1($before);$a=flatten_x1($after);$keys=array_unique(array_merge(array_keys($b),array_keys($a)));$changes=[];
 foreach($keys as $k){$bv=$b[$k]??null;$av=$a[$k]??null;if($bv!==$av)$changes[]=['key'=>$k,'before'=>$bv,'after'=>$av];if(count($changes)>=150)break;}
 if(!$changes)return;$rows=rows('audit');$rows[]=['id'=>nextid($rows),'created_at'=>now(),'admin_id'=>$_SESSION['admin_id']??'','action'=>'config_change','ip'=>client_ip(),'detail'=>count($changes).' alteração(ões)','changes'=>$changes];if(count($rows)>5000)$rows=array_slice($rows,-5000);setrows('audit',$rows);
}
function android_test_features():array{return ['theme'=>'Tema','language'=>'Idioma','menus'=>'Menus / botões','portal'=>'Portal / credenciais','players'=>'Players','vpn'=>'VPN','message'=>'Mensagem privada','announcement'=>'Anúncio','logo'=>'Logo','intro'=>'Intro','sports'=>'Sports','tmdb'=>'TMDB','update'=>'Atualização APK','parental'=>'Parental'];}
function android_test_for_user(string $userid):?array{foreach(rows('android_tests') as $r)if((string)($r['userid']??'')===$userid)return$r;return null;}
function save_android_test(string $userid,array $test):void{$test['userid']=$userid;$test['updated_at']=now();upsert_row('android_tests','userid',$userid,$test);}
