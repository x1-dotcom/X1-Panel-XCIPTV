# Validação X1 Panel v2.1

Executado localmente em PHP built-in server.

## PASS

- Login Owner com CSRF e sessão.
- Criação do preset de perfil **Minimal** através do admin.
- Registo de `LAB001` e `LAB002` por `connv2`.
- Pedido real de `licV3` e `licV4` para `LAB001`.
- Gravação de fingerprint/tema/idioma/perfil da configuração entregue.
- Novo `connv2` posterior à licença marcado como **Callback após entrega**.
- Laboratório APK filtrado por `userid`.
- Atribuição do mesmo perfil a dois dispositivos através da ação em lote.
- `php -l` em todos os 49 ficheiros PHP.

## Limite deliberado

O Laboratório distingue **entrega confirmada pelo servidor** de **renderização confirmada na APK**. Um callback posterior prova que a APK voltou a comunicar depois da entrega. Não é tecnicamente correto declarar que o tema/idioma foi visualmente aplicado sem observar a APK num Android real.
